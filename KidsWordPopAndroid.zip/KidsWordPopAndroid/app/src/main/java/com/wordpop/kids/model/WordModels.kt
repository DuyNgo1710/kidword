package com.wordpop.kids.model

import androidx.compose.ui.graphics.Color

data class WordItem(
    val word: String,
    val emoji: String
)

enum class WordCategory(
    val title: String,
    val icon: String,
    val accentColor: Color,
    val softBgColor: Color
) {
    ANIMALS(
        title = "Animals",
        icon = "🦁",
        accentColor = Color(0xFF10B981),
        softBgColor = Color(0xFFECFDF5)
    ),
    VEHICLES(
        title = "Vehicles",
        icon = "🚀",
        accentColor = Color(0xFF0EA5E9),
        softBgColor = Color(0xFFF0F9FF)
    ),
    FAMILY_STUFF(
        title = "Family Stuff",
        icon = "🏠",
        accentColor = Color(0xFFF43F5E),
        softBgColor = Color(0xFFFFF1F2)
    )
}
