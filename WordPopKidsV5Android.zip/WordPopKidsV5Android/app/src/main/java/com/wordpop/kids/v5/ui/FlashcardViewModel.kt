package com.wordpop.kids.v5.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.wordpop.kids.v5.data.WordRepository
import com.wordpop.kids.v5.model.Accomplishments
import com.wordpop.kids.v5.model.FontStyleChoice
import com.wordpop.kids.v5.model.LogicMode
import com.wordpop.kids.v5.model.LogicPuzzleState
import com.wordpop.kids.v5.model.QuizCardState
import com.wordpop.kids.v5.model.WordCategory
import com.wordpop.kids.v5.model.WordItem

enum class ScreenMode { HOME, QUIZ, WORD_LIST, LOGIC, SETTINGS, VERSION_HISTORY, SUMMARY }

data class WordPopV5UiState(
    val screen: ScreenMode = ScreenMode.HOME,
    val previousScreen: ScreenMode = ScreenMode.HOME,
    val readAloudEnabled: Boolean = true,
    val slowMode: Boolean = true,
    val autoBilingualVn: Boolean = false,
    val showVnOnCurrent: Boolean = false,
    val fontScale: Float = 1.0f,
    val fontStyle: FontStyleChoice = FontStyleChoice.DEFAULT,
    val animTrigger: Int = 0,
    val summaryRunId: Int = 0,
    // Quiz (10 random words per set)
    val category: WordCategory? = null,
    val quizCards: List<QuizCardState> = emptyList(),
    val currentIndex: Int = 0,
    val feedbackText: String = "What is this? Pick the right word!",
    val bestStars: Map<WordCategory, Int> = emptyMap(),
    // Logic Play (10 random from all 100 words)
    val logicMode: LogicMode? = null,
    val logicPuzzles: List<LogicPuzzleState> = emptyList(),
    val logicIndex: Int = 0,
    val logicFeedback: String = "Think carefully and pick your answer!",
    // Summary
    val summaryStars: Int = 0,
    val summaryTotal: Int = 10
) {
    val currentCard: QuizCardState? get() = quizCards.getOrNull(currentIndex)
    val quizStars: Int get() = quizCards.count { it.earnedStar }
    val currentLogic: LogicPuzzleState? get() = logicPuzzles.getOrNull(logicIndex)
    val logicStars: Int get() = logicPuzzles.count { it.earnedStar }
}

class FlashcardViewModel : ViewModel() {

    private val sessionSize = 10
    private val fontSteps = listOf(0.85f, 1.0f, 1.15f, 1.3f)

    var uiState by mutableStateOf(WordPopV5UiState())
        private set

    fun toggleReadAloud(): Boolean {
        val next = !uiState.readAloudEnabled
        uiState = uiState.copy(readAloudEnabled = next)
        return next
    }

    fun toggleSlowMode(): Boolean {
        val next = !uiState.slowMode
        uiState = uiState.copy(slowMode = next)
        return next
    }

    fun toggleAutoBilingual() {
        val next = !uiState.autoBilingualVn
        uiState = uiState.copy(autoBilingualVn = next, showVnOnCurrent = next)
    }

    fun toggleVnOnCurrent() {
        uiState = uiState.copy(showVnOnCurrent = !uiState.showVnOnCurrent)
    }

    fun decreaseFontSize() {
        val idx = fontSteps.indexOfFirst { kotlin.math.abs(it - uiState.fontScale) < 0.01f }
        val nextIdx = if (idx == -1) 0 else (idx - 1).coerceAtLeast(0)
        uiState = uiState.copy(fontScale = fontSteps[nextIdx])
    }

    fun increaseFontSize() {
        val idx = fontSteps.indexOfFirst { kotlin.math.abs(it - uiState.fontScale) < 0.01f }
        val nextIdx = if (idx == -1) 2 else (idx + 1).coerceAtMost(fontSteps.lastIndex)
        uiState = uiState.copy(fontScale = fontSteps[nextIdx])
    }

    fun selectFontStyle(choice: FontStyleChoice) {
        uiState = uiState.copy(fontStyle = choice)
    }

    fun replayAnimation() {
        uiState = uiState.copy(animTrigger = uiState.animTrigger + 1)
    }

    fun openSettings() {
        if (uiState.screen == ScreenMode.SETTINGS) {
            uiState = uiState.copy(screen = uiState.previousScreen)
        } else {
            uiState = uiState.copy(previousScreen = uiState.screen, screen = ScreenMode.SETTINGS)
        }
    }

    fun closeSettings() {
        uiState = uiState.copy(screen = uiState.previousScreen)
    }

    fun openWordList() {
        uiState = uiState.copy(screen = ScreenMode.WORD_LIST)
    }

    fun closeWordList() {
        uiState = uiState.copy(screen = ScreenMode.QUIZ)
    }

    fun openVersionHistory() {
        uiState = uiState.copy(screen = ScreenMode.VERSION_HISTORY)
    }

    fun closeVersionHistory() {
        uiState = uiState.copy(screen = ScreenMode.SETTINGS)
    }

    fun goHome() {
        uiState = uiState.copy(screen = ScreenMode.HOME)
    }

    /** Picks 10 random words out of the 20 in this category. */
    fun startCategory(category: WordCategory) {
        val allInCat = WordRepository.wordsFor(category)
        val picked = allInCat.shuffled().take(sessionSize)
        val cards = picked.map { target ->
            val distractors = allInCat.filter { it.word != target.word }.shuffled().take(3)
            QuizCardState(target = target, options = (distractors + target).shuffled())
        }
        uiState = uiState.copy(
            screen = ScreenMode.QUIZ,
            logicMode = null,
            category = category,
            quizCards = cards,
            currentIndex = 0,
            showVnOnCurrent = uiState.autoBilingualVn,
            feedbackText = "What is this? Pick the right word!"
        )
    }

    fun selectOption(chosen: WordItem): String {
        val card = uiState.currentCard ?: return ""
        val target = card.target
        if (card.answered) {
            if (chosen.word == target.word) replayAnimation()
            return chosen.word
        }

        val updatedList = uiState.quizCards.toMutableList()
        return if (chosen.word == target.word) {
            updatedList[uiState.currentIndex] = card.copy(
                answered = true,
                earnedStar = card.wrongChoices.isEmpty()
            )
            uiState = uiState.copy(
                quizCards = updatedList,
                animTrigger = uiState.animTrigger + 1,
                feedbackText = "Yes! ${target.word}! (${target.vnWord})"
            )
            "Great job! ${target.word}! ${target.sentenceEn}"
        } else {
            updatedList[uiState.currentIndex] = card.copy(wrongChoices = card.wrongChoices + chosen.word)
            uiState = uiState.copy(
                quizCards = updatedList,
                feedbackText = "That's ${chosen.word} - try again!"
            )
            "${chosen.word}. Try again!"
        }
    }

    fun prevQuestion() {
        if (uiState.currentIndex <= 0) return
        val prevIdx = uiState.currentIndex - 1
        val prevCard = uiState.quizCards[prevIdx]
        uiState = uiState.copy(
            currentIndex = prevIdx,
            showVnOnCurrent = uiState.autoBilingualVn,
            feedbackText = if (prevCard.answered) "Yes! ${prevCard.target.word}! (${prevCard.target.vnWord})" else "What is this? Pick the right word!"
        )
    }

    fun nextQuestion(): String? {
        val category = uiState.category ?: return null
        val nextIdx = uiState.currentIndex + 1
        return if (nextIdx >= uiState.quizCards.size) {
            val earned = uiState.quizStars
            val updatedBest = uiState.bestStars.toMutableMap()
            if (earned > (updatedBest[category] ?: 0)) updatedBest[category] = earned
            val acc = Accomplishments.forScore(earned)
            uiState = uiState.copy(
                screen = ScreenMode.SUMMARY,
                bestStars = updatedBest,
                summaryStars = earned,
                summaryTotal = uiState.quizCards.size,
                summaryRunId = uiState.summaryRunId + 1
            )
            "${acc.title}! ${acc.en}"
        } else {
            val nextCard = uiState.quizCards[nextIdx]
            uiState = uiState.copy(
                currentIndex = nextIdx,
                showVnOnCurrent = uiState.autoBilingualVn,
                feedbackText = if (nextCard.answered) "Yes! ${nextCard.target.word}! (${nextCard.target.vnWord})" else "What is this? Pick the right word!"
            )
            null
        }
    }

    /** Picks 10 random puzzles from the entire 100-word pool. */
    fun startLogicMode(mode: LogicMode): String {
        val allCats = WordCategory.entries
        val picked = WordRepository.allWords().shuffled().take(sessionSize)
        val puzzles = if (mode == LogicMode.MYSTERY_CLUE) {
            picked.map { target ->
                val distractors = WordRepository.wordsFor(target.category)
                    .filter { it.word != target.word }
                    .shuffled()
                    .take(3)
                LogicPuzzleState(
                    mode = LogicMode.MYSTERY_CLUE,
                    target = target,
                    options = (distractors + target).shuffled()
                )
            }
        } else {
            picked.map { odd ->
                val majCat = allCats.filter { it != odd.category }.random()
                val trio = WordRepository.wordsFor(majCat).shuffled().take(3)
                LogicPuzzleState(
                    mode = LogicMode.ODD_ONE_OUT,
                    target = odd,
                    options = (trio + odd).shuffled(),
                    majorityCategory = majCat
                )
            }
        }

        val first = puzzles.first()
        uiState = uiState.copy(
            screen = ScreenMode.LOGIC,
            logicMode = mode,
            logicPuzzles = puzzles,
            logicIndex = 0,
            showVnOnCurrent = uiState.autoBilingualVn,
            logicFeedback = if (mode == LogicMode.MYSTERY_CLUE) "Who am I? Pick the matching word!" else "Spot the odd one out!"
        )
        return if (mode == LogicMode.MYSTERY_CLUE) first.target.clueEn else "Which one does not belong with the others?"
    }

    fun selectLogicOption(chosen: WordItem): String {
        val p = uiState.currentLogic ?: return ""
        if (p.answered) {
            if (chosen.word == p.target.word) replayAnimation()
            return chosen.word
        }

        val updated = uiState.logicPuzzles.toMutableList()
        return if (chosen.word == p.target.word) {
            val msg = if (p.mode == LogicMode.MYSTERY_CLUE) {
                "${p.target.word} (${p.target.vnWord}) - ${p.target.sentenceEn}"
            } else {
                val maj = p.majorityCategory?.title ?: "the others"
                "Smart! ${p.target.word} is in ${p.target.category.title}, while the other 3 are $maj!"
            }
            updated[uiState.logicIndex] = p.copy(answered = true, earnedStar = p.wrongChoices.isEmpty())
            uiState = uiState.copy(
                logicPuzzles = updated,
                animTrigger = uiState.animTrigger + 1,
                logicFeedback = msg
            )
            if (p.mode == LogicMode.MYSTERY_CLUE) {
                "Awesome detective! It's ${p.target.word}! ${p.target.sentenceEn}"
            } else {
                val maj = p.majorityCategory?.title ?: "the others"
                "Smart thinking! ${p.target.word} is in ${p.target.category.title}, while the other three are $maj!"
            }
        } else {
            val hint = if (p.mode == LogicMode.MYSTERY_CLUE) {
                "Not ${chosen.word} - listen to the clue again!"
            } else {
                val maj = p.majorityCategory?.title ?: "the group"
                "${chosen.word} belongs with $maj - find the different one!"
            }
            updated[uiState.logicIndex] = p.copy(wrongChoices = p.wrongChoices + chosen.word)
            uiState = uiState.copy(logicPuzzles = updated, logicFeedback = hint)
            "${chosen.word}. Try again!"
        }
    }

    fun prevLogicPuzzle() {
        if (uiState.logicIndex <= 0) return
        val prevIdx = uiState.logicIndex - 1
        val p = uiState.logicPuzzles[prevIdx]
        val fb = if (p.answered) {
            if (p.mode == LogicMode.MYSTERY_CLUE) "${p.target.word} (${p.target.vnWord}) - ${p.target.sentenceEn}"
            else "Smart! ${p.target.word} is in ${p.target.category.title}, while the other 3 are ${p.majorityCategory?.title ?: "the others"}!"
        } else {
            if (p.mode == LogicMode.MYSTERY_CLUE) "Who am I? Pick the matching word!" else "Spot the odd one out!"
        }
        uiState = uiState.copy(logicIndex = prevIdx, showVnOnCurrent = uiState.autoBilingualVn, logicFeedback = fb)
    }

    fun nextLogicPuzzle(): String {
        val nextIdx = uiState.logicIndex + 1
        val mode = uiState.logicMode ?: LogicMode.MYSTERY_CLUE
        return if (nextIdx >= uiState.logicPuzzles.size) {
            val earned = uiState.logicStars
            val acc = Accomplishments.forScore(earned)
            uiState = uiState.copy(
                screen = ScreenMode.SUMMARY,
                summaryStars = earned,
                summaryTotal = uiState.logicPuzzles.size,
                summaryRunId = uiState.summaryRunId + 1
            )
            "${acc.title}! ${acc.en}"
        } else {
            val p = uiState.logicPuzzles[nextIdx]
            val fb = if (p.answered) {
                if (p.mode == LogicMode.MYSTERY_CLUE) "${p.target.word} (${p.target.vnWord}) - ${p.target.sentenceEn}"
                else "Smart! ${p.target.word} is in ${p.target.category.title}, while the other 3 are ${p.majorityCategory?.title ?: "the others"}!"
            } else {
                if (mode == LogicMode.MYSTERY_CLUE) "Who am I? Pick the matching word!" else "Spot the odd one out!"
            }
            uiState = uiState.copy(logicIndex = nextIdx, showVnOnCurrent = uiState.autoBilingualVn, logicFeedback = fb)
            if (p.answered) "" else if (mode == LogicMode.MYSTERY_CLUE) p.target.clueEn else "Which one does not belong with the others?"
        }
    }
}
