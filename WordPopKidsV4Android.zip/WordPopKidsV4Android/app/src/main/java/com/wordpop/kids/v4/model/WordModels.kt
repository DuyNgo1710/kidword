package com.wordpop.kids.v4.model

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

enum class FontStyleChoice(val label: String, val fontFamily: FontFamily) {
    DEFAULT("Clean", FontFamily.SansSerif),
    STORYBOOK("Storybook", FontFamily.Serif),
    TYPEWRITER("Typewriter", FontFamily.Monospace),
    PLAYFUL("Playful", FontFamily.Cursive)
}

enum class AnimType(val particles: Triple<String, String, String>, val auraColor: Color) {
    WAG(Triple("🐾", "💛", "✨"), Color(0xFFFDE047)),
    HOP(Triple("💨", "⭐", "🎉"), Color(0xFF86EFAC)),
    ZOOM(Triple("💨", "⚡", "🔥"), Color(0xFF7DD3FC)),
    FLY(Triple("☁️", "✨", "🌟"), Color(0xFFBAE6FD)),
    SWIM(Triple("🫧", "🌊", "💧"), Color(0xFF67E8F9)),
    ROAR(Triple("💥", "⚡", "🔥"), Color(0xFFFDBA74)),
    GLOW(Triple("✨", "🌟", "💫"), Color(0xFFFCD34D)),
    WRITE(Triple("💫", "🌈", "✨"), Color(0xFFF9A8D4))
}

data class WordItem(
    val word: String,
    val emoji: String,
    val vnWord: String,
    val sentenceEn: String,
    val sentenceVn: String,
    val clueEn: String,
    val clueVn: String,
    val animType: AnimType,
    val actionBadge: String,
    val category: WordCategory
)

enum class WordCategory(
    val title: String,
    val vnTitle: String,
    val icon: String,
    val accentColor: Color,
    val softBgColor: Color
) {
    ANIMALS(
        title = "Animals",
        vnTitle = "Động vật",
        icon = "🦁",
        accentColor = Color(0xFF10B981),
        softBgColor = Color(0xFFECFDF5)
    ),
    VEHICLES(
        title = "Vehicles",
        vnTitle = "Phương tiện",
        icon = "🚀",
        accentColor = Color(0xFF0EA5E9),
        softBgColor = Color(0xFFF0F9FF)
    ),
    FURNITURE(
        title = "Furniture",
        vnTitle = "Nội thất phòng khách",
        icon = "🛋️",
        accentColor = Color(0xFFF43F5E),
        softBgColor = Color(0xFFFFF1F2)
    ),
    STATIONERY(
        title = "Stationery",
        vnTitle = "Dụng cụ học tập",
        icon = "✏️",
        accentColor = Color(0xFFF59E0B),
        softBgColor = Color(0xFFFFFBEB)
    ),
    KITCHEN(
        title = "Kitchen",
        vnTitle = "Nhà bếp",
        icon = "🍳",
        accentColor = Color(0xFF0891B2),
        softBgColor = Color(0xFFECFEFF)
    )
}

enum class LogicMode(val title: String) {
    MYSTERY_CLUE("Mystery Clue"),
    ODD_ONE_OUT("Odd One Out")
}

data class QuizCardState(
    val target: WordItem,
    val options: List<WordItem>,
    val answered: Boolean = false,
    val wrongChoices: Set<String> = emptySet(),
    val earnedStar: Boolean = false
)

data class LogicPuzzleState(
    val mode: LogicMode,
    val target: WordItem,
    val options: List<WordItem>,
    val majorityCategory: WordCategory? = null,
    val answered: Boolean = false,
    val wrongChoices: Set<String> = emptySet(),
    val earnedStar: Boolean = false
)
