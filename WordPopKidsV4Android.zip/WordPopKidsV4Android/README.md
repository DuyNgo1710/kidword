# WordPop! Kids v4 (Android)

Registered under `com.wordpop.kids.v4` so it installs cleanly alongside earlier versions.

## What's New in v4.0
- **100 Simple Words (5 Categories x 20 Words):** Added **Kitchen (Nhà bếp)** and redesigned **Furniture (Nội thất phòng khách)** around Living Room items.
- **Bigger Hero Picture Stage & Vivid Animations:** Larger image stage with squash-and-stretch physics, glowing aura rings, and orbiting scene particles matching each sentence.
- **Full 100-Word Random Logic Play:** Both Mystery Clue and Odd One Out now shuffle randomly across all 100 words.
