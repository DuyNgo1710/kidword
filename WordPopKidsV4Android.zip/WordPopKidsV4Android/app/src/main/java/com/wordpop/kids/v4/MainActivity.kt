package com.wordpop.kids.v4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.wordpop.kids.v4.audio.TtsManager
import com.wordpop.kids.v4.data.WordRepository
import com.wordpop.kids.v4.model.AnimType
import com.wordpop.kids.v4.model.FontStyleChoice
import com.wordpop.kids.v4.model.LogicMode
import com.wordpop.kids.v4.model.WordCategory
import com.wordpop.kids.v4.model.WordItem
import com.wordpop.kids.v4.ui.FlashcardViewModel
import com.wordpop.kids.v4.ui.ScreenMode
import com.wordpop.kids.v4.ui.WordPopV4UiState
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var ttsManager: TtsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ttsManager = TtsManager(this)

        setContent {
            val vm: FlashcardViewModel = viewModel()
            val baseDensity = LocalDensity.current
            val scaledDensity = Density(
                density = baseDensity.density,
                fontScale = baseDensity.fontScale * vm.uiState.fontScale
            )
            MaterialTheme {
                CompositionLocalProvider(LocalDensity provides scaledDensity) {
                    ProvideTextStyle(value = TextStyle(fontFamily = vm.uiState.fontStyle.fontFamily)) {
                        WordPopV4App(
                            state = vm.uiState,
                    onSpeak = { text, force ->
                        if (force || vm.uiState.readAloudEnabled) {
                            ttsManager.speak(text, vm.uiState.slowMode)
                        }
                    },
                    onToggleReadAloud = {
                        val enabled = vm.toggleReadAloud()
                        if (enabled) ttsManager.speak("Read aloud is on", vm.uiState.slowMode)
                        else ttsManager.stop()
                    },
                    onToggleSlowMode = {
                        val slow = vm.toggleSlowMode()
                        ttsManager.speak(if (slow) "Slow voice" else "Normal voice", slow)
                    },
                    onToggleAutoBilingual = { vm.toggleAutoBilingual() },
                    onDecreaseFont = { vm.decreaseFontSize() },
                    onIncreaseFont = { vm.increaseFontSize() },
                    onSelectFontStyle = { vm.selectFontStyle(it) },
                    onToggleVnOnCurrent = { vm.toggleVnOnCurrent() },
                    onReplayAnim = { vm.replayAnimation() },
                    onOpenSettings = { vm.openSettings() },
                    onCloseSettings = { vm.closeSettings() },
                    onSelectCategory = { cat ->
                        vm.startCategory(cat)
                        if (vm.uiState.readAloudEnabled) ttsManager.speak(cat.title, vm.uiState.slowMode)
                    },
                    onSelectOption = { item ->
                        val spoken = vm.selectOption(item)
                        if (vm.uiState.readAloudEnabled && spoken.isNotEmpty()) {
                            ttsManager.speak(spoken, vm.uiState.slowMode)
                        }
                    },
                    onPrevQuestion = { vm.prevQuestion() },
                    onNextQuestion = {
                        val summarySpeech = vm.nextQuestion()
                        if (summarySpeech != null && vm.uiState.readAloudEnabled) {
                            ttsManager.speak(summarySpeech, vm.uiState.slowMode)
                        }
                    },
                    onStartLogic = { mode ->
                        val clueSpeech = vm.startLogicMode(mode)
                        if (vm.uiState.readAloudEnabled) ttsManager.speak(clueSpeech, vm.uiState.slowMode)
                    },
                    onSelectLogicOption = { item ->
                        val spoken = vm.selectLogicOption(item)
                        if (vm.uiState.readAloudEnabled && spoken.isNotEmpty()) {
                            ttsManager.speak(spoken, vm.uiState.slowMode)
                        }
                    },
                    onPrevLogic = { vm.prevLogicPuzzle() },
                    onNextLogic = {
                        val nextSpeech = vm.nextLogicPuzzle()
                        if (vm.uiState.readAloudEnabled && nextSpeech.isNotEmpty()) {
                            ttsManager.speak(nextSpeech, vm.uiState.slowMode)
                        }
                    },
                    onGoHome = {
                        ttsManager.stop()
                        vm.goHome()
                    }
                        )
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown()
    }
}

/**
 * Vivid multi-layer animated stage with squash-and-stretch physics,
 * expanding aura pulse, and 3 orbiting scene particles matching the sentence.
 */
@Composable
fun VividAnimatedStage(
    emoji: String,
    animType: AnimType,
    active: Boolean,
    triggerKey: Int,
    fontSize: TextUnit = 100.sp
) {
    val tx = remember { Animatable(0f) }
    val ty = remember { Animatable(0f) }
    val rot = remember { Animatable(0f) }
    val scX = remember { Animatable(1f) }
    val scY = remember { Animatable(1f) }
    val fxProgress = remember { Animatable(0f) }

    LaunchedEffect(active, triggerKey, emoji) {
        tx.snapTo(0f); ty.snapTo(0f); rot.snapTo(0f); scX.snapTo(1f); scY.snapTo(1f); fxProgress.snapTo(0f)
        if (!active) return@LaunchedEffect

        // Aura + orbiting scene particles burst twice in parallel with main physics animation
        launch {
            repeat(2) {
                fxProgress.snapTo(0f)
                fxProgress.animateTo(1f, tween(950))
            }
        }

        when (animType) {
            AnimType.WAG -> {
                repeat(2) {
                    launch { scX.animateTo(1.2f, tween(130)); scY.animateTo(1.12f, tween(130)) }
                    launch { ty.animateTo(-14f, tween(130)) }
                    rot.animateTo(-24f, tween(130))
                    rot.animateTo(24f, tween(160))
                    rot.animateTo(-18f, tween(140))
                    rot.animateTo(18f, tween(140))
                }
                launch { scX.animateTo(1.06f, tween(120)); scY.animateTo(1.06f, tween(120)); ty.animateTo(0f, tween(120)) }
                rot.animateTo(0f, tween(120))
            }
            AnimType.HOP -> {
                repeat(2) {
                    launch { scX.animateTo(1.22f, tween(100)); scY.animateTo(0.8f, tween(100)) }
                    ty.animateTo(8f, tween(100))
                    launch { scX.animateTo(0.9f, tween(210)); scY.animateTo(1.26f, tween(210)); rot.animateTo(-8f, tween(210)) }
                    ty.animateTo(-72f, tween(210))
                    launch { scX.animateTo(1.24f, tween(170)); scY.animateTo(0.78f, tween(170)); rot.animateTo(0f, tween(170)) }
                    ty.animateTo(0f, tween(170))
                }
                launch { scX.animateTo(1.06f, tween(130)); scY.animateTo(1.06f, tween(130)) }
            }
            AnimType.ZOOM -> {
                repeat(2) {
                    tx.snapTo(-150f)
                    scX.snapTo(1.18f); scY.snapTo(0.88f)
                    rot.snapTo(-12f)
                    launch { scX.animateTo(1.22f, tween(300)); scY.animateTo(1.05f, tween(300)); rot.animateTo(8f, tween(300)) }
                    tx.animateTo(44f, tween(300))
                    launch { rot.animateTo(-4f, tween(180)) }
                    tx.animateTo(-12f, tween(180))
                    launch { rot.animateTo(0f, tween(160)); scX.animateTo(1.06f, tween(160)); scY.animateTo(1.06f, tween(160)) }
                    tx.animateTo(0f, tween(160))
                }
            }
            AnimType.FLY -> {
                repeat(2) {
                    launch { tx.animateTo(38f, tween(260)); rot.animateTo(-14f, tween(260)); scX.animateTo(1.22f, tween(260)); scY.animateTo(1.22f, tween(260)) }
                    ty.animateTo(-56f, tween(260))
                    launch { tx.animateTo(-32f, tween(280)); rot.animateTo(14f, tween(280)) }
                    ty.animateTo(-34f, tween(280))
                    launch { tx.animateTo(0f, tween(200)); rot.animateTo(0f, tween(200)); scX.animateTo(1.06f, tween(200)); scY.animateTo(1.06f, tween(200)) }
                    ty.animateTo(0f, tween(200))
                }
            }
            AnimType.SWIM -> {
                repeat(2) {
                    launch { tx.animateTo(-38f, tween(240)); rot.animateTo(-12f, tween(240)); scX.animateTo(1.14f, tween(240)); scY.animateTo(1.1f, tween(240)) }
                    ty.animateTo(-22f, tween(240))
                    launch { tx.animateTo(38f, tween(280)); rot.animateTo(12f, tween(280)) }
                    ty.animateTo(16f, tween(280))
                }
                launch { tx.animateTo(0f, tween(180)); rot.animateTo(0f, tween(180)); scX.animateTo(1.06f, tween(180)); scY.animateTo(1.06f, tween(180)) }
                ty.animateTo(0f, tween(180))
            }
            AnimType.ROAR -> {
                repeat(2) {
                    launch { scX.animateTo(0.88f, tween(110)); scY.animateTo(0.88f, tween(110)) }
                    ty.animateTo(6f, tween(110))
                    launch { scX.animateTo(1.42f, tween(180)); scY.animateTo(1.42f, tween(180)); ty.animateTo(-12f, tween(180)) }
                    rot.animateTo(-10f, tween(90))
                    rot.animateTo(10f, tween(90))
                    rot.animateTo(-6f, tween(80))
                    rot.animateTo(6f, tween(80))
                }
                launch { scX.animateTo(1.08f, tween(150)); scY.animateTo(1.08f, tween(150)); ty.animateTo(0f, tween(150)) }
                rot.animateTo(0f, tween(150))
            }
            AnimType.GLOW -> {
                repeat(2) {
                    launch { scX.animateTo(1.32f, tween(320)); scY.animateTo(1.32f, tween(320)) }
                    rot.animateTo(360f, tween(600))
                    rot.snapTo(0f)
                    launch { scX.animateTo(1.08f, tween(180)); scY.animateTo(1.08f, tween(180)) }
                }
            }
            AnimType.WRITE -> {
                repeat(2) {
                    launch { tx.animateTo(-28f, tween(160)); ty.animateTo(-16f, tween(160)); scX.animateTo(1.16f, tween(160)); scY.animateTo(1.16f, tween(160)) }
                    rot.animateTo(-22f, tween(160))
                    launch { tx.animateTo(26f, tween(180)); ty.animateTo(12f, tween(180)) }
                    rot.animateTo(16f, tween(180))
                    launch { tx.animateTo(-16f, tween(150)); ty.animateTo(10f, tween(150)) }
                    rot.animateTo(-14f, tween(150))
                }
                launch { tx.animateTo(0f, tween(140)); ty.animateTo(0f, tween(140)); scX.animateTo(1.06f, tween(140)); scY.animateTo(1.06f, tween(140)) }
                rot.animateTo(0f, tween(140))
            }
        }
    }

    val p = fxProgress.value
    val particleAlpha = if (active && p > 0f && p < 1f) (1f - p) else 0f
    val (p1, p2, p3) = animType.particles

    Box(
        modifier = Modifier.fillMaxWidth().height(150.dp),
        contentAlignment = Alignment.Center
    ) {
        if (active && p > 0f) {
            // Expanding glowing aura ring
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .graphicsLayer(
                        scaleX = 0.7f + p * 0.95f,
                        scaleY = 0.7f + p * 0.95f,
                        alpha = (1f - p) * 0.45f
                    )
                    .clip(CircleShape)
                    .background(animType.auraColor)
            )
            // 3 Orbiting scene particles
            Text(
                text = p1,
                fontSize = 28.sp,
                modifier = Modifier.graphicsLayer(
                    translationX = -95f * p,
                    translationY = -75f * p,
                    scaleX = 0.6f + p * 0.7f,
                    scaleY = 0.6f + p * 0.7f,
                    alpha = particleAlpha
                )
            )
            Text(
                text = p2,
                fontSize = 28.sp,
                modifier = Modifier.graphicsLayer(
                    translationX = 95f * p,
                    translationY = -70f * p,
                    scaleX = 0.6f + p * 0.7f,
                    scaleY = 0.6f + p * 0.7f,
                    alpha = particleAlpha
                )
            )
            Text(
                text = p3,
                fontSize = 26.sp,
                modifier = Modifier.graphicsLayer(
                    translationY = -98f * p,
                    scaleX = 0.6f + p * 0.75f,
                    scaleY = 0.6f + p * 0.75f,
                    alpha = particleAlpha
                )
            )
        }

        Text(
            text = emoji,
            fontSize = fontSize,
            modifier = Modifier.graphicsLayer(
                translationX = tx.value,
                translationY = ty.value,
                rotationZ = rot.value,
                scaleX = scX.value,
                scaleY = scY.value
            )
        )
    }
}

@Composable
fun WordPopV4App(
    state: WordPopV4UiState,
    onSpeak: (String, Boolean) -> Unit,
    onToggleReadAloud: () -> Unit,
    onToggleSlowMode: () -> Unit,
    onToggleAutoBilingual: () -> Unit,
    onDecreaseFont: () -> Unit,
    onIncreaseFont: () -> Unit,
    onSelectFontStyle: (FontStyleChoice) -> Unit,
    onToggleVnOnCurrent: () -> Unit,
    onReplayAnim: () -> Unit,
    onOpenSettings: () -> Unit,
    onCloseSettings: () -> Unit,
    onSelectCategory: (WordCategory) -> Unit,
    onSelectOption: (WordItem) -> Unit,
    onPrevQuestion: () -> Unit,
    onNextQuestion: () -> Unit,
    onStartLogic: (LogicMode) -> Unit,
    onSelectLogicOption: (WordItem) -> Unit,
    onPrevLogic: () -> Unit,
    onNextLogic: () -> Unit,
    onGoHome: () -> Unit
) {
    val bgBrush = Brush.verticalGradient(
        colors = listOf(Color(0xFFFEF9C3), Color(0xFFE0F2FE), Color(0xFFFCE7F3))
    )

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0284C7))
                    .statusBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (state.screen != ScreenMode.HOME) {
                    TextButton(
                        onClick = onGoHome,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                    ) {
                        Text("← Home", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.wordpop_logo),
                            contentDescription = "WordPop! Kids v4 logo",
                            modifier = Modifier.size(38.dp).clip(RoundedCornerShape(10.dp))
                        )
                        Column {
                            Text("WordPop! Kids", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("Version 4.0 • 100 Words", color = Color(0xFFBAE6FD), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = onToggleReadAloud,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.readAloudEnabled) Color(0xFFFBBF24) else Color.White.copy(alpha = 0.22f),
                            contentColor = if (state.readAloudEnabled) Color(0xFF0F172A) else Color.White
                        )
                    ) {
                        Text(if (state.readAloudEnabled) "🔊 ON" else "🔇 OFF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.size(38.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f))
                    ) {
                        Text("⚙️", fontSize = 18.sp)
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(bgBrush)
                .padding(innerPadding)
                .padding(14.dp)
        ) {
            when (state.screen) {
                ScreenMode.HOME -> HomeScreen(
                    bestStars = state.bestStars,
                    onSelectCategory = onSelectCategory,
                    onSpeakCategory = { cat -> onSpeak(cat.title, true) },
                    onStartLogic = onStartLogic
                )
                ScreenMode.QUIZ -> QuizScreen(
                    state = state,
                    onSpeakText = { text -> onSpeak(text, true) },
                    onReplayAnim = onReplayAnim,
                    onToggleVn = onToggleVnOnCurrent,
                    onSelectOption = onSelectOption,
                    onPrev = onPrevQuestion,
                    onNext = onNextQuestion
                )
                ScreenMode.LOGIC -> LogicScreen(
                    state = state,
                    onSpeakText = { text -> onSpeak(text, true) },
                    onToggleVn = onToggleVnOnCurrent,
                    onSelectOption = onSelectLogicOption,
                    onPrev = onPrevLogic,
                    onNext = onNextLogic
                )
                ScreenMode.SETTINGS -> SettingsScreen(
                    state = state,
                    onToggleReadAloud = onToggleReadAloud,
                    onToggleSlowMode = onToggleSlowMode,
                    onToggleAutoBilingual = onToggleAutoBilingual,
                    onDecreaseFont = onDecreaseFont,
                    onIncreaseFont = onIncreaseFont,
                    onSelectFontStyle = onSelectFontStyle,
                    onClose = onCloseSettings
                )
                ScreenMode.SUMMARY -> SummaryScreen(
                    state = state,
                    onSpeakSummary = { onSpeak("Awesome job! You got ${state.summaryStars} stars in ${state.summaryTitle}!", true) },
                    onPlayAgain = {
                        val lm = state.logicMode
                        if (lm != null) onStartLogic(lm)
                        else state.category?.let(onSelectCategory)
                    },
                    onGoHome = onGoHome
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    bestStars: Map<WordCategory, Int>,
    onSelectCategory: (WordCategory) -> Unit,
    onSpeakCategory: (WordCategory) -> Unit,
    onStartLogic: (LogicMode) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color.White.copy(alpha = 0.92f),
            border = BorderStroke(2.dp, Color(0xFFBAE6FD))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.wordpop_logo),
                    contentDescription = "WordPop mascot",
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(14.dp))
                )
                Column {
                    Text("Pick a World to Play!", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
                    Text("100 words • Vivid animations • Full Logic", fontSize = 12.sp, color = Color(0xFF64748B))
                }
            }
        }

        WordCategory.entries.forEach { cat ->
            val total = WordRepository.wordsFor(cat).size
            val best = bestStars[cat] ?: 0
            val suffix = when (cat) {
                WordCategory.KITCHEN -> "  ★ NEW"
                WordCategory.FURNITURE -> "  ★ LIVING ROOM"
                else -> ""
            }
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onSelectCategory(cat) },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = cat.accentColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(cat.icon, fontSize = 26.sp)
                        }
                        Column {
                            Text("${cat.title}$suffix", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("${cat.vnTitle}  •  ⭐ $best / $total", fontSize = 12.sp, color = Color(0xFFFEF3C7), fontWeight = FontWeight.SemiBold)
                        }
                    }

                    IconButton(
                        onClick = { onSpeakCategory(cat) },
                        modifier = Modifier.size(36.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f))
                    ) {
                        Text("🔊", fontSize = 16.sp)
                    }
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF8B5CF6)),
            elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🧩", fontSize = 24.sp)
                    }
                    Column {
                        Text("Logic Play  •  All 100 Words", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("Random riddles & Odd One Out across 5 worlds", fontSize = 12.sp, color = Color(0xFFEDE9FE))
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { onStartLogic(LogicMode.MYSTERY_CLUE) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF6D28D9))
                    ) {
                        Text("🕵️ Mystery Clue", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Button(
                        onClick = { onStartLogic(LogicMode.ODD_ONE_OUT) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFFA21CAF))
                    ) {
                        Text("🔎 Odd One Out", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun QuizScreen(
    state: WordPopV4UiState,
    onSpeakText: (String) -> Unit,
    onReplayAnim: () -> Unit,
    onToggleVn: () -> Unit,
    onSelectOption: (WordItem) -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    val category = state.category ?: return
    val card = state.currentCard ?: return
    val target = card.target

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${category.icon} ${category.title} • ${state.currentIndex + 1}/${state.quizCards.size}",
                fontWeight = FontWeight.Bold,
                color = Color(0xFF334155),
                fontSize = 14.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(
                    onClick = onToggleVn,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFFFE4E6), contentColor = Color(0xFFBE123C))
                ) {
                    Text("🇻🇳 VN Hint", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Surface(shape = RoundedCornerShape(50), color = Color(0xFFFEF3C7)) {
                    Text("⭐ ${state.quizStars}", modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), fontWeight = FontWeight.Bold, color = Color(0xFF92400E), fontSize = 13.sp)
                }
            }
        }

        LinearProgressIndicator(
            progress = { (state.currentIndex + 1).toFloat() / state.quizCards.size.toFloat() },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
            color = category.accentColor,
            trackColor = Color.White
        )

        // BIGGER Hero Picture & Vivid Animation Stage
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 245.dp)
                .clickable {
                    onSpeakText(target.word)
                    if (card.answered) onReplayAnim()
                },
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(3.dp, category.accentColor.copy(alpha = 0.4f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                if (card.answered) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color(0xFFFCD34D),
                        modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                    ) {
                        Text(
                            text = target.actionBadge,
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF0F172A)
                        )
                    }
                }

                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    VividAnimatedStage(
                        emoji = target.emoji,
                        animType = target.animType,
                        active = card.answered,
                        triggerKey = state.animTrigger,
                        fontSize = 102.sp
                    )
                    if (state.showVnOnCurrent) {
                        Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFFFF1F2), border = BorderStroke(1.dp, Color(0xFFFECDD3))) {
                            Text(
                                text = "🇻🇳 ${target.vnWord} — ${target.sentenceVn}",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF9F1239),
                                textAlign = TextAlign.Center
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    Button(
                        onClick = { onSpeakText(target.word) },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0EA5E9))
                    ) {
                        Text("🔊 Hear Word", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (card.answered) Color(0xFFECFDF5) else Color.White.copy(alpha = 0.85f),
            border = BorderStroke(1.dp, if (card.answered) Color(0xFFA7F3D0) else Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = state.feedbackText,
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (card.answered) Color(0xFF047857) else Color(0xFF475569)
                )
                if (card.answered) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "“${target.sentenceEn}”",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF065F46),
                            modifier = Modifier.weight(1f, fill = false),
                            textAlign = TextAlign.Center
                        )
                        IconButton(
                            onClick = {
                                onSpeakText(target.sentenceEn)
                                onReplayAnim()
                            },
                            modifier = Modifier.size(28.dp).clip(CircleShape).background(Color(0xFFD1FAE5))
                        ) {
                            Text("🔊", fontSize = 12.sp)
                        }
                    }
                    Text(
                        text = "🇻🇳 ${target.sentenceVn}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFBE123C),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            card.options.chunked(2).forEach { rowItems ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { opt ->
                        val isCorrectShown = card.answered && opt.word == target.word
                        val isWrong = opt.word in card.wrongChoices
                        val bg = when {
                            isCorrectShown -> Color(0xFF10B981)
                            isWrong -> Color(0xFFFFF1F2)
                            else -> Color.White
                        }
                        val fg = when {
                            isCorrectShown -> Color.White
                            isWrong -> Color(0xFFE11D48)
                            else -> Color(0xFF1E293B)
                        }
                        Surface(
                            modifier = Modifier.weight(1f).height(58.dp).clickable { onSelectOption(opt) },
                            shape = RoundedCornerShape(16.dp),
                            color = bg,
                            border = BorderStroke(2.dp, if (isCorrectShown) Color(0xFF059669) else if (isWrong) Color(0xFFFDA4AF) else Color(0xFFE2E8F0)),
                            shadowElevation = 2.dp
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(opt.word, color = fg, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                                IconButton(
                                    onClick = { onSpeakText(opt.word) },
                                    modifier = Modifier.size(30.dp).clip(CircleShape).background(Color(0xFFE0F2FE))
                                ) {
                                    Text("🔊", fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (state.currentIndex > 0) {
                FilledTonalButton(
                    onClick = onPrev,
                    modifier = Modifier.height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("← Prev", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
            if (card.answered) {
                Button(
                    onClick = onNext,
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Text(
                        text = if (state.currentIndex == state.quizCards.size - 1) "See My Stars! 🏆" else "Next Word →",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun LogicScreen(
    state: WordPopV4UiState,
    onSpeakText: (String) -> Unit,
    onToggleVn: () -> Unit,
    onSelectOption: (WordItem) -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    val puzzle = state.currentLogic ?: return
    val isMystery = puzzle.mode == LogicMode.MYSTERY_CLUE

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${if (isMystery) "🕵️ Mystery Clue" else "🔎 Odd One Out"} • ${state.logicIndex + 1}/${state.logicPuzzles.size}",
                fontWeight = FontWeight.Bold,
                color = Color(0xFF5B21B6),
                fontSize = 14.sp
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalButton(
                    onClick = onToggleVn,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFFFE4E6), contentColor = Color(0xFFBE123C))
                ) {
                    Text("🇻🇳 VN Clue", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Surface(shape = RoundedCornerShape(50), color = Color(0xFFFEF3C7)) {
                    Text("⭐ ${state.logicStars}", modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), fontWeight = FontWeight.Bold, color = Color(0xFF92400E), fontSize = 13.sp)
                }
            }
        }

        LinearProgressIndicator(
            progress = { (state.logicIndex + 1).toFloat() / state.logicPuzzles.size.toFloat() },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
            color = Color(0xFF8B5CF6),
            trackColor = Color.White
        )

        Card(
            modifier = Modifier.fillMaxWidth().heightIn(min = 235.dp),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(3.dp, Color(0xFFDDD6FE)),
            elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                if (puzzle.answered) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color(0xFFFCD34D),
                        modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                    ) {
                        Text(
                            text = puzzle.target.actionBadge,
                            modifier = Modifier.padding(horizontal = 11.dp, vertical = 5.dp),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF0F172A)
                        )
                    }
                }

                Column(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    VividAnimatedStage(
                        emoji = if (puzzle.answered) puzzle.target.emoji else if (isMystery) "❓" else "🔎",
                        animType = puzzle.target.animType,
                        active = puzzle.answered,
                        triggerKey = state.animTrigger,
                        fontSize = 86.sp
                    )
                    Text(
                        text = if (isMystery) "“${puzzle.target.clueEn}”" else "Which one does NOT belong with the others?",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B),
                        textAlign = TextAlign.Center
                    )
                    if (state.showVnOnCurrent) {
                        Spacer(modifier = Modifier.height(5.dp))
                        Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFFFF1F2), border = BorderStroke(1.dp, Color(0xFFFECDD3))) {
                            Text(
                                text = if (isMystery) "🇻🇳 ${puzzle.target.clueVn}" else "🇻🇳 Hình nào KHÔNG cùng nhóm với 3 hình còn lại?",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF9F1239),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { onSpeakText(if (isMystery) puzzle.target.clueEn else "Which one does not belong with the others?") },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
                    ) {
                        Text("🔊 Hear Clue", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (puzzle.answered) Color(0xFFECFDF5) else Color.White.copy(alpha = 0.85f),
            border = BorderStroke(1.dp, if (puzzle.answered) Color(0xFFA7F3D0) else Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = state.logicFeedback,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                textAlign = TextAlign.Center,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (puzzle.answered) Color(0xFF047857) else Color(0xFF475569)
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            puzzle.options.chunked(2).forEach { rowItems ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { opt ->
                        val isCorrectShown = puzzle.answered && opt.word == puzzle.target.word
                        val isWrong = opt.word in puzzle.wrongChoices
                        val bg = when {
                            isCorrectShown -> Color(0xFF10B981)
                            isWrong -> Color(0xFFFFF1F2)
                            else -> Color.White
                        }
                        val fg = when {
                            isCorrectShown -> Color.White
                            isWrong -> Color(0xFFE11D48)
                            else -> Color(0xFF1E293B)
                        }
                        Surface(
                            modifier = Modifier.weight(1f).height(60.dp).clickable { onSelectOption(opt) },
                            shape = RoundedCornerShape(16.dp),
                            color = bg,
                            border = BorderStroke(2.dp, if (isCorrectShown) Color(0xFF059669) else if (isWrong) Color(0xFFFDA4AF) else Color(0xFFE2E8F0)),
                            shadowElevation = 2.dp
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (isMystery) opt.word else "${opt.emoji} ${opt.word}",
                                    color = fg,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onSpeakText(opt.word) },
                                    modifier = Modifier.size(30.dp).clip(CircleShape).background(Color(0xFFEDE9FE))
                                ) {
                                    Text("🔊", fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (state.logicIndex > 0) {
                FilledTonalButton(
                    onClick = onPrev,
                    modifier = Modifier.height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("← Prev", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
            if (puzzle.answered) {
                Button(
                    onClick = onNext,
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
                ) {
                    Text(
                        text = if (state.logicIndex == state.logicPuzzles.size - 1) "See My Stars! 🏆" else "Next Puzzle →",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    state: WordPopV4UiState,
    onToggleReadAloud: () -> Unit,
    onToggleSlowMode: () -> Unit,
    onToggleAutoBilingual: () -> Unit,
    onDecreaseFont: () -> Unit,
    onIncreaseFont: () -> Unit,
    onSelectFontStyle: (FontStyleChoice) -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(
                painter = painterResource(id = R.drawable.wordpop_logo),
                contentDescription = "WordPop! Kids v4 logo",
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(16.dp))
            )
            Column {
                Text("WordPop! Kids v4", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
                Text("Package: com.wordpop.kids.v4", fontSize = 12.sp, color = Color(0xFF64748B))
            }
        }

        Text("LEARNING PREFERENCES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))

        SettingRow("🔊 Read Aloud", "Speak words, clues, and sentences", if (state.readAloudEnabled) "ON" else "OFF", state.readAloudEnabled, onToggleReadAloud)
        SettingRow("🐢 Voice Speed", "Slower voice is easier for 6-year-olds", if (state.slowMode) "Slow" else "Normal", state.slowMode, onToggleSlowMode)
        SettingRow("🇻🇳 Vietnamese Bilingual Bridge", "Auto-show matched Vietnamese hints", if (state.autoBilingualVn) "ON" else "OFF", state.autoBilingualVn, onToggleAutoBilingual)

        // Font Size Control (A- / A+)
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("🔠 Font Size", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B))
                    Text("Make words bigger or smaller", fontSize = 11.sp, color = Color(0xFF64748B))
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalButton(
                        onClick = onDecreaseFont,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) { Text("A−", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                    Text(
                        text = "${(state.fontScale * 100).toInt()}%",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = Color(0xFF0284C7)
                    )
                    FilledTonalButton(
                        onClick = onIncreaseFont,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) { Text("A+", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                }
            }
        }

        // Font Style Picker + Live Preview
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("✍️ Font Style", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B))
                FontStyleChoice.entries.chunked(2).forEach { rowChoices ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowChoices.forEach { choice ->
                            val selected = choice == state.fontStyle
                            OutlinedButton(
                                onClick = { onSelectFontStyle(choice) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Color(0xFF0284C7) else Color(0xFFCBD5E1)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (selected) Color(0xFFE0F2FE) else Color.White,
                                    contentColor = if (selected) Color(0xFF0369A1) else Color(0xFF475569)
                                )
                            ) {
                                Text(choice.label, fontFamily = choice.fontFamily, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
                Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFF8FAFC), border = BorderStroke(1.dp, Color(0xFFE2E8F0)), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "🐶 A dog loves to wag its tail!",
                        modifier = Modifier.padding(10.dp),
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFF334155)
                    )
                }
            }
        }

        Text("VERSION HISTORY & WHAT'S NEW", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))

        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFECFEFF)),
            border = BorderStroke(2.dp, Color(0xFFA5F3FC))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Version 4.0 (Current)", fontWeight = FontWeight.ExtraBold, color = Color(0xFF155E75), fontSize = 15.sp)
                Text("• New Kitchen (Nhà bếp) category with 20 words (100 total!)", fontSize = 13.sp, color = Color(0xFF164E63))
                Text("• Furniture (Nội thất phòng khách) focused on Living Room items", fontSize = 13.sp, color = Color(0xFF164E63))
                Text("• Bigger picture stage + vivid animations with aura & particles", fontSize = 13.sp, color = Color(0xFF164E63))
                Text("• Full 100-word random Mystery Clue & Odd One Out", fontSize = 13.sp, color = Color(0xFF164E63))
            }
        }

        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)), border = BorderStroke(1.dp, Color(0xFFFDE68A))) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Version 3.0", fontWeight = FontWeight.Bold, color = Color(0xFF92400E), fontSize = 13.sp)
                Text("• Matched VN-EN sentences, animations, ← Prev, and Stationery", fontSize = 12.sp, color = Color(0xFF78350F))
            }
        }

        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFEEF2FF)), border = BorderStroke(1.dp, Color(0xFFC7D2FE))) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Version 2.0", fontWeight = FontWeight.Bold, color = Color(0xFF312E81), fontSize = 13.sp)
                Text("• Cute mascot logo, Settings, Full-Sentence Echo, and Logic Play", fontSize = 12.sp, color = Color(0xFF3730A3))
            }
        }

        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, Color(0xFFE2E8F0))) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Version 1.0", fontWeight = FontWeight.Bold, color = Color(0xFF334155), fontSize = 13.sp)
                Text("• 60 starter words across 3 categories with Read Aloud", fontSize = 12.sp, color = Color(0xFF64748B))
            }
        }

        Button(
            onClick = onClose,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
        ) {
            Text("Done", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, badge: String, active: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B))
                Text(subtitle, fontSize = 11.sp, color = Color(0xFF64748B))
            }
            Button(
                onClick = onClick,
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (active) Color(0xFF10B981) else Color(0xFFE2E8F0),
                    contentColor = if (active) Color.White else Color(0xFF475569)
                )
            ) {
                Text(badge, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SummaryScreen(
    state: WordPopV4UiState,
    onSpeakSummary: () -> Unit,
    onPlayAgain: () -> Unit,
    onGoHome: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🏆", fontSize = 74.sp)
        Spacer(modifier = Modifier.height(10.dp))
        Text("Awesome Job!", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
        Spacer(modifier = Modifier.height(6.dp))
        Text("You finished ${state.summaryTitle}!", fontSize = 15.sp, color = Color(0xFF475569), textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(18.dp))

        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7))) {
            Column(modifier = Modifier.padding(horizontal = 32.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("⭐ ${state.summaryStars} / ${state.summaryTotal}", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFB45309))
                Text("First-Try Stars", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
        OutlinedButton(onClick = onSpeakSummary, shape = RoundedCornerShape(50)) {
            Text("🔊 Hear Celebration", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(22.dp))
        Button(
            onClick = onPlayAgain,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
        ) {
            Text("🔄 Play Again", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(10.dp))
        FilledTonalButton(
            onClick = onGoHome,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text("🏠 Back to Home", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
