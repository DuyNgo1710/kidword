# WordPop! Kids v5 (Android)

Registered under `com.wordpop.kids.v5` so it installs cleanly side-by-side alongside earlier versions.

## What's New in v5.0
- **Fixed Clickable Verb Badge & Matched Verbs:** Tapping the top-right action verb in Quiz, Mystery Clue, or Odd One Out replays its exact matched vivid animation!
- **Quick 10-Question Random Sets + Reset Button:** Every category and Logic Play mode deals 10 random cards with a `🔄 New 10` Reset button in the top bar.
- **Vibrant 10-Star Visual Counter:** Watch all 10 star tiles light up one by one as you play.
- **5-Second Grand Celebration:** Fireworks & dancing trophy show with custom English & Vietnamese praise for every score from 1/10 to 10/10, then options for Home or a New Set of 10.
