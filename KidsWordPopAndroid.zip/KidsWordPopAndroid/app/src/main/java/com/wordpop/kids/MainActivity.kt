package com.wordpop.kids

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.wordpop.kids.audio.TtsManager
import com.wordpop.kids.data.WordRepository
import com.wordpop.kids.model.WordCategory
import com.wordpop.kids.ui.FlashcardViewModel
import com.wordpop.kids.ui.QuizUiState
import com.wordpop.kids.ui.ScreenMode

class MainActivity : ComponentActivity() {

    private lateinit var ttsManager: TtsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ttsManager = TtsManager(this)

        setContent {
            MaterialTheme {
                val vm: FlashcardViewModel = viewModel()
                WordPopApp(
                    state = vm.uiState,
                    onSpeak = { text, force ->
                        if (force || vm.uiState.readAloudEnabled) {
                            ttsManager.speak(text, vm.uiState.slowMode)
                        }
                    },
                    onToggleReadAloud = {
                        val enabled = vm.toggleReadAloud()
                        if (enabled) ttsManager.speak("Read aloud is on", vm.uiState.slowMode)
                        else ttsManager.stop()
                    },
                    onToggleSlowMode = {
                        val slow = vm.toggleSlowMode()
                        ttsManager.speak(if (slow) "Slow voice" else "Normal voice", slow)
                    },
                    onSelectCategory = { cat ->
                        vm.startCategory(cat)
                        if (vm.uiState.readAloudEnabled) {
                            ttsManager.speak(cat.title, vm.uiState.slowMode)
                        }
                    },
                    onSelectOption = { item ->
                        val spoken = vm.selectOption(item)
                        if (vm.uiState.readAloudEnabled && spoken.isNotEmpty()) {
                            ttsManager.speak(spoken, vm.uiState.slowMode)
                        }
                    },
                    onNext = {
                        val summarySpeech = vm.nextQuestion()
                        if (summarySpeech != null && vm.uiState.readAloudEnabled) {
                            ttsManager.speak(summarySpeech, vm.uiState.slowMode)
                        }
                    },
                    onGoHome = {
                        ttsManager.stop()
                        vm.goHome()
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown()
    }
}

@Composable
fun WordPopApp(
    state: QuizUiState,
    onSpeak: (String, Boolean) -> Unit,
    onToggleReadAloud: () -> Unit,
    onToggleSlowMode: () -> Unit,
    onSelectCategory: (WordCategory) -> Unit,
    onSelectOption: (com.wordpop.kids.model.WordItem) -> Unit,
    onNext: () -> Unit,
    onGoHome: () -> Unit
) {
    val bgBrush = Brush.verticalGradient(
        colors = listOf(Color(0xFFFEF9C3), Color(0xFFE0F2FE), Color(0xFFFCE7F3))
    )

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0284C7))
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (state.screen != ScreenMode.HOME) {
                    TextButton(
                        onClick = onGoHome,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                    ) {
                        Text("← Home", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                } else {
                    Text(
                        text = "🌟 WordPop!",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 20.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(
                        onClick = onToggleSlowMode,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = Color.White.copy(alpha = 0.22f),
                            contentColor = Color.White
                        )
                    ) {
                        Text(if (state.slowMode) "🐢 Slow" else "🐇 Normal", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onToggleReadAloud,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.readAloudEnabled) Color(0xFFFBBF24) else Color.White.copy(alpha = 0.22f),
                            contentColor = if (state.readAloudEnabled) Color(0xFF0F172A) else Color.White
                        )
                    ) {
                        Text(
                            text = if (state.readAloudEnabled) "🔊 ON" else "🔇 OFF",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(bgBrush)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            when (state.screen) {
                ScreenMode.HOME -> HomeScreen(
                    bestStars = state.bestStars,
                    onSelectCategory = onSelectCategory,
                    onSpeakCategory = { cat -> onSpeak(cat.title, true) }
                )
                ScreenMode.QUIZ -> QuizScreen(
                    state = state,
                    onSpeakWord = { word -> onSpeak(word, true) },
                    onSelectOption = onSelectOption,
                    onNext = onNext
                )
                ScreenMode.SUMMARY -> SummaryScreen(
                    state = state,
                    onSpeakSummary = {
                        val title = state.category?.title ?: "this game"
                        onSpeak("Awesome job! You got ${state.stars} stars in $title!", true)
                    },
                    onPlayAgain = { state.category?.let(onSelectCategory) },
                    onGoHome = onGoHome
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    bestStars: Map<WordCategory, Int>,
    onSelectCategory: (WordCategory) -> Unit,
    onSpeakCategory: (WordCategory) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Pick a World to Play!",
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF1E293B)
            )
            Text(
                text = "60 fun English words • Tap 🔊 anytime to listen",
                fontSize = 14.sp,
                color = Color(0xFF475569)
            )
        }

        WordCategory.entries.forEach { cat ->
            val total = WordRepository.wordsFor(cat).size
            val best = bestStars[cat] ?: 0
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectCategory(cat) },
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = cat.accentColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color.White.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(cat.icon, fontSize = 36.sp)
                        }
                        Column {
                            Text(
                                text = cat.title,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "$total Simple Words",
                                fontSize = 13.sp,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                            Text(
                                text = "Best: ⭐ $best / $total",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFEF3C7)
                            )
                        }
                    }

                    IconButton(
                        onClick = { onSpeakCategory(cat) },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.25f))
                    ) {
                        Text("🔊", fontSize = 20.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun QuizScreen(
    state: QuizUiState,
    onSpeakWord: (String) -> Unit,
    onSelectOption: (com.wordpop.kids.model.WordItem) -> Unit,
    onNext: () -> Unit
) {
    val category = state.category ?: return
    val target = state.currentWord ?: return

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Progress + Stars Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${category.icon} ${category.title}  •  ${state.currentIndex + 1} / ${state.deck.size}",
                fontWeight = FontWeight.Bold,
                color = Color(0xFF334155),
                fontSize = 15.sp
            )
            Surface(
                shape = RoundedCornerShape(50),
                color = Color(0xFFFEF3C7)
            ) {
                Text(
                    text = "⭐ ${state.stars}",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF92400E)
                )
            }
        }

        LinearProgressIndicator(
            progress = { (state.currentIndex + 1).toFloat() / state.deck.size.toFloat() },
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(50)),
            color = category.accentColor,
            trackColor = Color.White
        )

        // Picture Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
                .clickable { onSpeakWord(target.word) },
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(3.dp, category.accentColor.copy(alpha = 0.35f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(target.emoji, fontSize = 84.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { onSpeakWord(target.word) },
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0EA5E9))
                ) {
                    Text("🔊 Hear Word", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }

        // Feedback Banner
        Text(
            text = state.feedbackText,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = if (state.answeredCorrectly) Color(0xFF059669) else Color(0xFF475569)
        )

        // 4 Options (2x2 Grid)
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            state.options.chunked(2).forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowItems.forEach { opt ->
                        val isCorrectShown = state.answeredCorrectly && opt.word == target.word
                        val isWrong = opt.word in state.wrongChoices

                        val bgColor = when {
                            isCorrectShown -> Color(0xFF10B981)
                            isWrong -> Color(0xFFFFF1F2)
                            else -> Color.White
                        }
                        val textColor = when {
                            isCorrectShown -> Color.White
                            isWrong -> Color(0xFFE11D48)
                            else -> Color(0xFF1E293B)
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .height(74.dp)
                                .clickable { onSelectOption(opt) },
                            shape = RoundedCornerShape(20.dp),
                            color = bgColor,
                            border = BorderStroke(
                                2.dp,
                                if (isCorrectShown) Color(0xFF059669)
                                else if (isWrong) Color(0xFFFDA4AF)
                                else Color(0xFFE2E8F0)
                            ),
                            shadowElevation = 3.dp
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = opt.word,
                                    color = textColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onSpeakWord(opt.word) },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFE0F2FE))
                                ) {
                                    Text("🔊", fontSize = 15.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (state.answeredCorrectly) {
            Spacer(modifier = Modifier.weight(1f))
            Button(
                onClick = onNext,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
            ) {
                Text(
                    text = if (state.currentIndex == state.deck.size - 1) "See My Stars! 🏆" else "Next Word →",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SummaryScreen(
    state: QuizUiState,
    onSpeakSummary: () -> Unit,
    onPlayAgain: () -> Unit,
    onGoHome: () -> Unit
) {
    val categoryTitle = state.category?.title ?: "WordPop"
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🏆", fontSize = 76.sp)
        Spacer(modifier = Modifier.height(12.dp))
        Text("Awesome Job!", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "You finished all ${state.deck.size} words in $categoryTitle!",
            fontSize = 16.sp,
            color = Color(0xFF475569),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(20.dp))

        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7))
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 32.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("⭐ ${state.stars} / ${state.deck.size}", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFB45309))
                Text("First-Try Stars", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        OutlinedButton(onClick = onSpeakSummary, shape = RoundedCornerShape(50)) {
            Text("🔊 Hear Celebration", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = onPlayAgain,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
        ) {
            Text("🔄 Play Again", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(10.dp))
        FilledTonalButton(
            onClick = onGoHome,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text("🏠 Pick Another Category", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
