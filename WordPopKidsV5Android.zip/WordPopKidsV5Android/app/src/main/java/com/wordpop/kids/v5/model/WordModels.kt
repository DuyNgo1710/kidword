package com.wordpop.kids.v5.model

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

enum class FontStyleChoice(val label: String, val fontFamily: FontFamily) {
    DEFAULT("Clean", FontFamily.SansSerif),
    STORYBOOK("Storybook", FontFamily.Serif),
    TYPEWRITER("Typewriter", FontFamily.Monospace),
    PLAYFUL("Playful", FontFamily.Cursive)
}

enum class AnimType(val particles: Triple<String, String, String>, val auraColor: Color) {
    WAG(Triple("🐾", "💛", "✨"), Color(0xFFFDE047)),
    HOP(Triple("💨", "⭐", "🎉"), Color(0xFF86EFAC)),
    ZOOM(Triple("💨", "⚡", "🔥"), Color(0xFF7DD3FC)),
    FLY(Triple("☁️", "✨", "🌟"), Color(0xFFBAE6FD)),
    SWIM(Triple("🫧", "🌊", "💧"), Color(0xFF67E8F9)),
    ROAR(Triple("💥", "⚡", "🔥"), Color(0xFFFDBA74)),
    GLOW(Triple("✨", "🌟", "💫"), Color(0xFFFCD34D)),
    WRITE(Triple("💫", "🌈", "✨"), Color(0xFFF9A8D4))
}

data class WordItem(
    val word: String,
    val emoji: String,
    val vnWord: String,
    val sentenceEn: String,
    val sentenceVn: String,
    val clueEn: String,
    val clueVn: String,
    val animType: AnimType,
    val actionBadge: String,
    val category: WordCategory
)

enum class WordCategory(
    val title: String,
    val vnTitle: String,
    val icon: String,
    val accentColor: Color,
    val softBgColor: Color
) {
    ANIMALS("Animals", "Động vật", "🦁", Color(0xFF10B981), Color(0xFFECFDF5)),
    VEHICLES("Vehicles", "Phương tiện", "🚀", Color(0xFF0EA5E9), Color(0xFFF0F9FF)),
    FURNITURE("Furniture", "Nội thất phòng khách", "🛋️", Color(0xFFF43F5E), Color(0xFFFFF1F2)),
    STATIONERY("Stationery", "Dụng cụ học tập", "✏️", Color(0xFFF59E0B), Color(0xFFFFFBEB)),
    KITCHEN("Kitchen", "Nhà bếp", "🍳", Color(0xFF0891B2), Color(0xFFECFEFF))
}

enum class LogicMode(val title: String) {
    MYSTERY_CLUE("Mystery Clue"),
    ODD_ONE_OUT("Odd One Out")
}

data class QuizCardState(
    val target: WordItem,
    val options: List<WordItem>,
    val answered: Boolean = false,
    val wrongChoices: Set<String> = emptySet(),
    val earnedStar: Boolean = false
)

data class LogicPuzzleState(
    val mode: LogicMode,
    val target: WordItem,
    val options: List<WordItem>,
    val majorityCategory: WordCategory? = null,
    val answered: Boolean = false,
    val wrongChoices: Set<String> = emptySet(),
    val earnedStar: Boolean = false
)

data class AccomplishmentMessage(
    val icon: String,
    val title: String,
    val en: String,
    val vn: String
)

object Accomplishments {
    fun forScore(score: Int): AccomplishmentMessage = when (score.coerceIn(0, 10)) {
        0 -> AccomplishmentMessage("🌱", "Great Try, Explorer!", "You practiced all 10 words—every try makes your brain stronger!", "Bé đã luyện hết 10 từ—mỗi lần thử giúp bé giỏi hơn đấy!")
        1 -> AccomplishmentMessage("✨", "1/10 — First Spark!", "You earned your very first star! Keep tapping and listening!", "Bé đạt 1/10 ngôi sao đầu tiên! Tiếp tục nghe và chơi nhé!")
        2 -> AccomplishmentMessage("🌟", "2/10 — Warming Up!", "Two bright stars! You're starting to spot the words!", "2/10 sao sáng! Bé bắt đầu nhận ra nhiều từ rồi đó!")
        3 -> AccomplishmentMessage("🎈", "3/10 — Nice Start!", "Three stars already! Your English ears are waking up!", "3/10 sao rồi! Đôi tai tiếng Anh của bé nhạy hơn hẳn!")
        4 -> AccomplishmentMessage("🚀", "4/10 — Climbing High!", "Four awesome stars! You're almost halfway to ten!", "4/10 sao tuyệt vời! Bé sắp đi được nửa chặng đường rồi!")
        5 -> AccomplishmentMessage("⭐", "5/10 — Halfway Hero!", "Five shining stars! Halfway there—way to go, champ!", "5/10 sao lấp lánh! Đạt nửa chặng đường rồi, giỏi lắm!")
        6 -> AccomplishmentMessage("🌈", "6/10 — Super Learner!", "Six stars! You know more than half of the whole set!", "6/10 sao! Bé trả lời đúng hơn một nửa bộ từ rồi!")
        7 -> AccomplishmentMessage("🪄", "7/10 — Word Wizard!", "Seven dazzling stars! You're getting really fast and sharp!", "7/10 sao rực rỡ! Bé học rất nhanh và tinh mắt!")
        8 -> AccomplishmentMessage("🏅", "8/10 — Amazing Star!", "Eight out of ten! You're almost a total English master!", "8/10 sao xuất sắc! Bé sắp trở thành cao thủ tiếng Anh rồi!")
        9 -> AccomplishmentMessage("👑", "9/10 — So Close to Perfect!", "Nine out of ten! Incredible job—just one tiny step from 10!", "9/10 sao tuyệt đỉnh! Chỉ còn một bước nhỏ nữa là trọn điểm 10!")
        else -> AccomplishmentMessage("🏆", "10/10 — PERFECT CHAMPION!", "TEN OUT OF TEN! Unstoppable WordPop! Superstar!", "10/10 HOÀN HẢO! Bé là nhà vô địch WordPop! siêu đỉnh!")
    }
}
