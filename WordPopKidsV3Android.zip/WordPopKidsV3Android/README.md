# WordPop! Kids v3 (Android)

Registered under `com.wordpop.kids.v3` so v1, v2, and v3 can all stay installed side-by-side on your Android phone.

## What's New in v3.0
- **Matched VN–EN Hints & Sentences:** Every Vietnamese hint matches its English echo sentence 1-to-1 across all 80 words.
- **Expressive Sentence Animations:** Pictures wag, hop, zoom, fly, swim, roar, glow, or sketch to match each sentence when answered correctly.
- **Previous Question Navigation:** Tap `← Prev` anytime in Quiz or Logic Play to review or replay earlier words without losing stars.
- **New Category — Stationery (Dụng cụ học tập):** 20 new school and art words (80 words total).
