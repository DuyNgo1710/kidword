package com.wordpop.kids.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class TtsManager(context: Context) {
    private var tts: TextToSpeech? = null
    private var isReady = false

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.setPitch(1.08f)
                isReady = true
            }
        }
    }

    fun speak(text: String, slowMode: Boolean) {
        if (!isReady) return
        tts?.setSpeechRate(if (slowMode) 0.78f else 1.0f)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "wordpop_${System.currentTimeMillis()}")
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
