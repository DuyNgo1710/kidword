package com.wordpop.kids.v5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.wordpop.kids.v5.analytics.KidsAnalytics
import com.wordpop.kids.v5.audio.TtsManager
import com.wordpop.kids.v5.data.WordRepository
import com.wordpop.kids.v5.model.Accomplishments
import com.wordpop.kids.v5.model.AnimType
import com.wordpop.kids.v5.model.FontStyleChoice
import com.wordpop.kids.v5.model.LogicMode
import com.wordpop.kids.v5.model.WordCategory
import com.wordpop.kids.v5.model.WordItem
import com.wordpop.kids.v5.ui.FlashcardViewModel
import com.wordpop.kids.v5.ui.ScreenMode
import com.wordpop.kids.v5.ui.WordPopV5UiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var ttsManager: TtsManager
    private lateinit var analytics: KidsAnalytics

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ttsManager = TtsManager(this)
        analytics = KidsAnalytics(this)

        setContent {
            val vm: FlashcardViewModel = viewModel()
            val baseDensity = LocalDensity.current
            val scaledDensity = Density(
                density = baseDensity.density,
                fontScale = baseDensity.fontScale * vm.uiState.fontScale
            )
            MaterialTheme {
                CompositionLocalProvider(LocalDensity provides scaledDensity) {
                    ProvideTextStyle(value = TextStyle(fontFamily = vm.uiState.fontStyle.fontFamily)) {
                        WordPopV5App(
                            state = vm.uiState,
                            onSpeak = { text, force ->
                                if (force || vm.uiState.readAloudEnabled) {
                                    ttsManager.speak(text, vm.uiState.slowMode)
                                }
                            },
                            onToggleReadAloud = {
                                val enabled = vm.toggleReadAloud()
                                if (enabled) ttsManager.speak("Read aloud is on", vm.uiState.slowMode)
                                else ttsManager.stop()
                            },
                            onToggleSlowMode = {
                                val slow = vm.toggleSlowMode()
                                ttsManager.speak(if (slow) "Slow voice" else "Normal voice", slow)
                            },
                            onToggleAutoBilingual = { vm.toggleAutoBilingual() },
                            onDecreaseFont = { vm.decreaseFontSize(); analytics.logFontChanged((vm.uiState.fontScale * 100).toInt(), vm.uiState.fontStyle.label) },
                            onIncreaseFont = { vm.increaseFontSize(); analytics.logFontChanged((vm.uiState.fontScale * 100).toInt(), vm.uiState.fontStyle.label) },
                            onSelectFontStyle = { vm.selectFontStyle(it); analytics.logFontChanged((vm.uiState.fontScale * 100).toInt(), it.label) },
                            onToggleVnOnCurrent = { vm.toggleVnOnCurrent(); analytics.logVnHintToggled(vm.uiState.showVnOnCurrent) },
                            onReplayAnim = { vm.replayAnimation() },
                            onOpenSettings = { vm.openSettings() },
                            onCloseSettings = { vm.closeSettings() },
                            onOpenWordList = { vm.openWordList(); vm.uiState.category?.let { analytics.logWordListOpened(it.title) } },
                            onCloseWordList = { vm.closeWordList() },
                            onOpenVersionHistory = { vm.openVersionHistory() },
                            onCloseVersionHistory = { vm.closeVersionHistory() },
                            onResetSession = {
                                val s = vm.uiState
                                if (s.screen == ScreenMode.QUIZ && s.category != null) {
                                    vm.startCategory(s.category)
                                    if (vm.uiState.readAloudEnabled) ttsManager.speak("New set of ten! ${s.category.title}", vm.uiState.slowMode)
                                } else if (s.screen == ScreenMode.LOGIC && s.logicMode != null) {
                                    val clue = vm.startLogicMode(s.logicMode)
                                    if (vm.uiState.readAloudEnabled) ttsManager.speak(clue, vm.uiState.slowMode)
                                }
                            },
                            onSelectCategory = { cat ->
                                vm.startCategory(cat)
                                analytics.logCategoryStarted(cat.title)
                                if (vm.uiState.readAloudEnabled) ttsManager.speak(cat.title, vm.uiState.slowMode)
                            },
                            onSelectOption = { item ->
                                val spoken = vm.selectOption(item)
                                if (vm.uiState.readAloudEnabled && spoken.isNotEmpty()) {
                                    ttsManager.speak(spoken, vm.uiState.slowMode)
                                }
                            },
                            onPrevQuestion = { vm.prevQuestion() },
                            onNextQuestion = {
                                val catName = vm.uiState.category?.title ?: "quiz"
                                val summarySpeech = vm.nextQuestion()
                                if (summarySpeech != null) {
                                    analytics.logSessionCompleted(catName, vm.uiState.summaryStars)
                                    if (vm.uiState.readAloudEnabled) ttsManager.speak(summarySpeech, vm.uiState.slowMode)
                                }
                            },
                            onStartLogic = { mode ->
                                val clueSpeech = vm.startLogicMode(mode)
                                analytics.logLogicStarted(mode.title)
                                if (vm.uiState.readAloudEnabled) ttsManager.speak(clueSpeech, vm.uiState.slowMode)
                            },
                            onSelectLogicOption = { item ->
                                val spoken = vm.selectLogicOption(item)
                                if (vm.uiState.readAloudEnabled && spoken.isNotEmpty()) {
                                    ttsManager.speak(spoken, vm.uiState.slowMode)
                                }
                            },
                            onPrevLogic = { vm.prevLogicPuzzle() },
                            onNextLogic = {
                                val logicName = vm.uiState.logicMode?.title ?: "logic"
                                val nextSpeech = vm.nextLogicPuzzle()
                                if (vm.uiState.screen == ScreenMode.SUMMARY) {
                                    analytics.logSessionCompleted(logicName, vm.uiState.summaryStars)
                                }
                                if (vm.uiState.readAloudEnabled && nextSpeech.isNotEmpty()) {
                                    ttsManager.speak(nextSpeech, vm.uiState.slowMode)
                                }
                            },
                            onGoHome = {
                                ttsManager.stop()
                                vm.goHome()
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ttsManager.shutdown()
    }
}

@Composable
fun StarJourneyTrail(
    total: Int,
    activeIndex: Int,
    answeredAt: (Int) -> Boolean,
    starredAt: (Int) -> Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        for (i in 0 until total) {
            val isCurrent = i == activeIndex
            val answered = answeredAt(i)
            val starred = starredAt(i)
            val bg = when {
                answered && starred -> Color(0xFFFEF3C7)
                answered -> Color(0xFFA7F3D0)
                isCurrent -> Color(0xFF0EA5E9)
                else -> Color.White
            }
            val border = when {
                isCurrent -> Color(0xFF0369A1)
                answered && starred -> Color(0xFFF59E0B)
                answered -> Color(0xFF10B981)
                else -> Color(0xFFE2E8F0)
            }
            Surface(
                modifier = Modifier.weight(1f).height(28.dp),
                shape = RoundedCornerShape(8.dp),
                color = bg,
                border = BorderStroke(if (isCurrent) 2.dp else 1.dp, border)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = when {
                            answered && starred -> "⭐"
                            answered -> "✓"
                            else -> "${i + 1}"
                        },
                        fontSize = if (answered && starred) 13.sp else 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isCurrent && !answered) Color.White else if (answered) Color(0xFF065F46) else Color(0xFF94A3B8)
                    )
                }
            }
        }
    }
}

@Composable
fun VividAnimatedStage(
    emoji: String,
    animType: AnimType,
    active: Boolean,
    triggerKey: Int,
    fontSize: TextUnit = 98.sp
) {
    val tx = remember { Animatable(0f) }
    val ty = remember { Animatable(0f) }
    val rot = remember { Animatable(0f) }
    val scX = remember { Animatable(1f) }
    val scY = remember { Animatable(1f) }
    val fxProgress = remember { Animatable(0f) }

    LaunchedEffect(active, triggerKey, emoji) {
        tx.snapTo(0f); ty.snapTo(0f); rot.snapTo(0f); scX.snapTo(1f); scY.snapTo(1f); fxProgress.snapTo(0f)
        if (!active) return@LaunchedEffect

        launch {
            repeat(2) {
                fxProgress.snapTo(0f)
                fxProgress.animateTo(1f, tween(950))
            }
        }

        when (animType) {
            AnimType.WAG -> {
                repeat(2) {
                    launch { scX.animateTo(1.2f, tween(130)); scY.animateTo(1.12f, tween(130)); ty.animateTo(-14f, tween(130)) }
                    rot.animateTo(-24f, tween(130))
                    rot.animateTo(24f, tween(160))
                    rot.animateTo(-18f, tween(140))
                    rot.animateTo(18f, tween(140))
                }
                launch { scX.animateTo(1.06f, tween(120)); scY.animateTo(1.06f, tween(120)); ty.animateTo(0f, tween(120)) }
                rot.animateTo(0f, tween(120))
            }
            AnimType.HOP -> {
                repeat(2) {
                    launch { scX.animateTo(1.22f, tween(100)); scY.animateTo(0.8f, tween(100)) }
                    ty.animateTo(8f, tween(100))
                    launch { scX.animateTo(0.9f, tween(210)); scY.animateTo(1.26f, tween(210)); rot.animateTo(-8f, tween(210)) }
                    ty.animateTo(-72f, tween(210))
                    launch { scX.animateTo(1.24f, tween(170)); scY.animateTo(0.78f, tween(170)); rot.animateTo(0f, tween(170)) }
                    ty.animateTo(0f, tween(170))
                }
                launch { scX.animateTo(1.06f, tween(130)); scY.animateTo(1.06f, tween(130)) }
            }
            AnimType.ZOOM -> {
                repeat(2) {
                    tx.snapTo(-150f); scX.snapTo(1.18f); scY.snapTo(0.88f); rot.snapTo(-12f)
                    launch { scX.animateTo(1.22f, tween(300)); scY.animateTo(1.05f, tween(300)); rot.animateTo(8f, tween(300)) }
                    tx.animateTo(44f, tween(300))
                    launch { rot.animateTo(-4f, tween(180)) }
                    tx.animateTo(-12f, tween(180))
                    launch { rot.animateTo(0f, tween(160)); scX.animateTo(1.06f, tween(160)); scY.animateTo(1.06f, tween(160)) }
                    tx.animateTo(0f, tween(160))
                }
            }
            AnimType.FLY -> {
                repeat(2) {
                    launch { tx.animateTo(38f, tween(260)); rot.animateTo(-14f, tween(260)); scX.animateTo(1.22f, tween(260)); scY.animateTo(1.22f, tween(260)) }
                    ty.animateTo(-56f, tween(260))
                    launch { tx.animateTo(-32f, tween(280)); rot.animateTo(14f, tween(280)) }
                    ty.animateTo(-34f, tween(280))
                    launch { tx.animateTo(0f, tween(200)); rot.animateTo(0f, tween(200)); scX.animateTo(1.06f, tween(200)); scY.animateTo(1.06f, tween(200)) }
                    ty.animateTo(0f, tween(200))
                }
            }
            AnimType.SWIM -> {
                repeat(2) {
                    launch { tx.animateTo(-38f, tween(240)); rot.animateTo(-12f, tween(240)); scX.animateTo(1.14f, tween(240)); scY.animateTo(1.1f, tween(240)) }
                    ty.animateTo(-22f, tween(240))
                    launch { tx.animateTo(38f, tween(280)); rot.animateTo(12f, tween(280)) }
                    ty.animateTo(16f, tween(280))
                }
                launch { tx.animateTo(0f, tween(180)); rot.animateTo(0f, tween(180)); scX.animateTo(1.06f, tween(180)); scY.animateTo(1.06f, tween(180)) }
                ty.animateTo(0f, tween(180))
            }
            AnimType.ROAR -> {
                repeat(2) {
                    launch { scX.animateTo(0.88f, tween(110)); scY.animateTo(0.88f, tween(110)) }
                    ty.animateTo(6f, tween(110))
                    launch { scX.animateTo(1.42f, tween(180)); scY.animateTo(1.42f, tween(180)); ty.animateTo(-12f, tween(180)) }
                    rot.animateTo(-10f, tween(90))
                    rot.animateTo(10f, tween(90))
                    rot.animateTo(-6f, tween(80))
                    rot.animateTo(6f, tween(80))
                }
                launch { scX.animateTo(1.08f, tween(150)); scY.animateTo(1.08f, tween(150)); ty.animateTo(0f, tween(150)) }
                rot.animateTo(0f, tween(150))
            }
            AnimType.GLOW -> {
                repeat(2) {
                    launch { scX.animateTo(1.32f, tween(320)); scY.animateTo(1.32f, tween(320)) }
                    rot.animateTo(360f, tween(600))
                    rot.snapTo(0f)
                    launch { scX.animateTo(1.08f, tween(180)); scY.animateTo(1.08f, tween(180)) }
                }
            }
            AnimType.WRITE -> {
                repeat(2) {
                    launch { tx.animateTo(-28f, tween(160)); ty.animateTo(-16f, tween(160)); scX.animateTo(1.16f, tween(160)); scY.animateTo(1.16f, tween(160)) }
                    rot.animateTo(-22f, tween(160))
                    launch { tx.animateTo(26f, tween(180)); ty.animateTo(12f, tween(180)) }
                    rot.animateTo(16f, tween(180))
                    launch { tx.animateTo(-16f, tween(150)); ty.animateTo(10f, tween(150)) }
                    rot.animateTo(-14f, tween(150))
                }
                launch { tx.animateTo(0f, tween(140)); ty.animateTo(0f, tween(140)); scX.animateTo(1.06f, tween(140)); scY.animateTo(1.06f, tween(140)) }
                rot.animateTo(0f, tween(140))
            }
        }
    }

    val p = fxProgress.value
    val particleAlpha = if (active && p > 0f && p < 1f) (1f - p) else 0f
    val (p1, p2, p3) = animType.particles

    Box(modifier = Modifier.fillMaxWidth().heightIn(min = 104.dp, max = 148.dp), contentAlignment = Alignment.Center) {
        if (active && p > 0f) {
            Box(
                modifier = Modifier
                    .size(118.dp)
                    .graphicsLayer(scaleX = 0.7f + p * 0.95f, scaleY = 0.7f + p * 0.95f, alpha = (1f - p) * 0.45f)
                    .clip(CircleShape)
                    .background(animType.auraColor)
            )
            Text(p1, fontSize = 26.sp, modifier = Modifier.graphicsLayer(translationX = -92f * p, translationY = -72f * p, scaleX = 0.6f + p * 0.7f, scaleY = 0.6f + p * 0.7f, alpha = particleAlpha))
            Text(p2, fontSize = 26.sp, modifier = Modifier.graphicsLayer(translationX = 92f * p, translationY = -68f * p, scaleX = 0.6f + p * 0.7f, scaleY = 0.6f + p * 0.7f, alpha = particleAlpha))
            Text(p3, fontSize = 24.sp, modifier = Modifier.graphicsLayer(translationY = -94f * p, scaleX = 0.6f + p * 0.75f, scaleY = 0.6f + p * 0.75f, alpha = particleAlpha))
        }

        Text(
            text = emoji,
            fontSize = fontSize,
            modifier = Modifier.graphicsLayer(
                translationX = tx.value,
                translationY = ty.value,
                rotationZ = rot.value,
                scaleX = scX.value,
                scaleY = scY.value
            )
        )
    }
}

@Composable
fun WordPopV5App(
    state: WordPopV5UiState,
    onSpeak: (String, Boolean) -> Unit,
    onToggleReadAloud: () -> Unit,
    onToggleSlowMode: () -> Unit,
    onToggleAutoBilingual: () -> Unit,
    onDecreaseFont: () -> Unit,
    onIncreaseFont: () -> Unit,
    onSelectFontStyle: (FontStyleChoice) -> Unit,
    onToggleVnOnCurrent: () -> Unit,
    onReplayAnim: () -> Unit,
    onOpenSettings: () -> Unit,
    onCloseSettings: () -> Unit,
    onOpenWordList: () -> Unit,
    onCloseWordList: () -> Unit,
    onOpenVersionHistory: () -> Unit,
    onCloseVersionHistory: () -> Unit,
    onResetSession: () -> Unit,
    onSelectCategory: (WordCategory) -> Unit,
    onSelectOption: (WordItem) -> Unit,
    onPrevQuestion: () -> Unit,
    onNextQuestion: () -> Unit,
    onStartLogic: (LogicMode) -> Unit,
    onSelectLogicOption: (WordItem) -> Unit,
    onPrevLogic: () -> Unit,
    onNextLogic: () -> Unit,
    onGoHome: () -> Unit
) {
    val bgBrush = Brush.verticalGradient(
        colors = listOf(Color(0xFFFEF9C3), Color(0xFFE0F2FE), Color(0xFFFCE7F3))
    )
    val inSession = state.screen == ScreenMode.QUIZ || state.screen == ScreenMode.LOGIC

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0284C7))
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (state.screen != ScreenMode.HOME) {
                    TextButton(
                        onClick = onGoHome,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                    ) {
                        Text("← Home", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.wordpop_logo),
                            contentDescription = "WordPop! Kids v5 logo",
                            modifier = Modifier.size(36.dp).clip(RoundedCornerShape(10.dp))
                        )
                        Column {
                            Text("WordPop! Kids", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                            Text("v5.0 • 10-Card Quest", color = Color(0xFFBAE6FD), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (inSession) {
                        FilledTonalButton(
                            onClick = onResetSession,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Color.White.copy(alpha = 0.22f),
                                contentColor = Color.White
                            )
                        ) {
                            Text("🔄 New 10", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Button(
                        onClick = onToggleReadAloud,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.readAloudEnabled) Color(0xFFFBBF24) else Color.White.copy(alpha = 0.22f),
                            contentColor = if (state.readAloudEnabled) Color(0xFF0F172A) else Color.White
                        )
                    ) {
                        Text(if (state.readAloudEnabled) "🔊 ON" else "🔇 OFF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier.size(36.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f))
                    ) {
                        Text("⚙️", fontSize = 17.sp)
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(bgBrush)
                .padding(innerPadding)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            when (state.screen) {
                ScreenMode.HOME -> HomeScreen(
                    bestStars = state.bestStars,
                    onSelectCategory = onSelectCategory,
                    onSpeakCategory = { cat -> onSpeak(cat.title, true) },
                    onStartLogic = onStartLogic
                )
                ScreenMode.QUIZ -> QuizScreen(
                    state = state,
                    onSpeakText = { text -> onSpeak(text, true) },
                    onReplayAnim = onReplayAnim,
                    onOpenWordList = onOpenWordList,
                    onToggleVn = onToggleVnOnCurrent,
                    onSelectOption = onSelectOption,
                    onPrev = onPrevQuestion,
                    onNext = onNextQuestion
                )
                ScreenMode.WORD_LIST -> WordListScreen(
                    category = state.category,
                    onSpeakText = { text -> onSpeak(text, true) },
                    onBackToQuiz = onCloseWordList
                )
                ScreenMode.LOGIC -> LogicScreen(
                    state = state,
                    onSpeakText = { text -> onSpeak(text, true) },
                    onReplayAnim = onReplayAnim,
                    onToggleVn = onToggleVnOnCurrent,
                    onSelectOption = onSelectLogicOption,
                    onPrev = onPrevLogic,
                    onNext = onNextLogic
                )
                ScreenMode.SETTINGS -> SettingsScreen(
                    state = state,
                    onToggleReadAloud = onToggleReadAloud,
                    onToggleSlowMode = onToggleSlowMode,
                    onToggleAutoBilingual = onToggleAutoBilingual,
                    onDecreaseFont = onDecreaseFont,
                    onIncreaseFont = onIncreaseFont,
                    onSelectFontStyle = onSelectFontStyle,
                    onOpenVersionHistory = onOpenVersionHistory,
                    onClose = onCloseSettings
                )
                ScreenMode.VERSION_HISTORY -> VersionHistoryScreen(
                    onBackToSettings = onCloseVersionHistory
                )
                ScreenMode.SUMMARY -> CelebrationSummaryScreen(
                    state = state,
                    onSpeakText = { text -> onSpeak(text, true) },
                    onPlayAgain = {
                        val lm = state.logicMode
                        if (lm != null) onStartLogic(lm)
                        else state.category?.let(onSelectCategory)
                    },
                    onGoHome = onGoHome
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    bestStars: Map<WordCategory, Int>,
    onSelectCategory: (WordCategory) -> Unit,
    onSpeakCategory: (WordCategory) -> Unit,
    onStartLogic: (LogicMode) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color.White.copy(alpha = 0.92f),
            border = BorderStroke(2.dp, Color(0xFFBAE6FD))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.wordpop_logo),
                    contentDescription = "WordPop mascot",
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(14.dp))
                )
                Column {
                    Text("Pick a 10-Word Quest!", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
                    Text("100 words • Quick 10-card sets • Star party!", fontSize = 12.sp, color = Color(0xFF64748B))
                }
            }
        }

        WordCategory.entries.forEach { cat ->
            val best = bestStars[cat] ?: 0
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onSelectCategory(cat) },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = cat.accentColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(cat.icon, fontSize = 26.sp)
                        }
                        Column {
                            Text(cat.title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("${cat.vnTitle}  •  ⭐ $best/10", fontSize = 12.sp, color = Color(0xFFFEF3C7), fontWeight = FontWeight.SemiBold)
                        }
                    }

                    IconButton(
                        onClick = { onSpeakCategory(cat) },
                        modifier = Modifier.size(36.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f))
                    ) {
                        Text("🔊", fontSize = 16.sp)
                    }
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF8B5CF6)),
            elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🧩", fontSize = 24.sp)
                    }
                    Column {
                        Text("Logic Play  •  10 Random / 100", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("Random riddles & Odd One Out from all 100 words", fontSize = 12.sp, color = Color(0xFFEDE9FE))
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { onStartLogic(LogicMode.MYSTERY_CLUE) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF6D28D9))
                    ) {
                        Text("🕵️ Mystery Clue", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Button(
                        onClick = { onStartLogic(LogicMode.ODD_ONE_OUT) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFFA21CAF))
                    ) {
                        Text("🔎 Odd One Out", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun QuizScreen(
    state: WordPopV5UiState,
    onSpeakText: (String) -> Unit,
    onReplayAnim: () -> Unit,
    onOpenWordList: () -> Unit,
    onToggleVn: () -> Unit,
    onSelectOption: (WordItem) -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    val category = state.category ?: return
    val card = state.currentCard ?: return
    val target = card.target

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Prominent Kid-Friendly 10-Star Counter Card
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color(0xFFFFFBEB),
            border = BorderStroke(2.dp, Color(0xFFFDE68A)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${category.icon} Card ${state.currentIndex + 1} / ${state.quizCards.size}",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF78350F),
                        fontSize = 15.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalButton(
                            onClick = onOpenWordList,
                            contentPadding = PaddingValues(horizontal = 9.dp, vertical = 2.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFE0F2FE), contentColor = Color(0xFF0369A1))
                        ) { Text("📖 List", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        FilledTonalButton(
                            onClick = onToggleVn,
                            contentPadding = PaddingValues(horizontal = 9.dp, vertical = 2.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFFFE4E6), contentColor = Color(0xFFBE123C))
                        ) { Text("🇻🇳 VN", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        Surface(shape = RoundedCornerShape(50), color = Color(0xFFFBBF24)) {
                            Text("⭐ ${state.quizStars}/10", modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), fontWeight = FontWeight.ExtraBold, color = Color(0xFF0F172A), fontSize = 13.sp)
                        }
                    }
                }
                StarJourneyTrail(
                    total = state.quizCards.size,
                    activeIndex = state.currentIndex,
                    answeredAt = { state.quizCards[it].answered },
                    starredAt = { state.quizCards[it].earnedStar }
                )
            }
        }

        // Responsive Hero Stage fills available space cleanly on every phone!
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clickable {
                    onSpeakText(target.word)
                    if (card.answered) onReplayAnim()
                },
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(3.dp, category.accentColor.copy(alpha = 0.4f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                if (card.answered) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color(0xFFFCD34D),
                        shadowElevation = 3.dp,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp)
                            .clickable {
                                onReplayAnim()
                                onSpeakText(target.sentenceEn)
                            }
                    ) {
                        Text(
                            text = target.actionBadge,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF0F172A)
                        )
                    }
                }

                Column(
                    modifier = Modifier.fillMaxSize().padding(vertical = 10.dp, horizontal = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    VividAnimatedStage(
                        emoji = target.emoji,
                        animType = target.animType,
                        active = card.answered,
                        triggerKey = state.animTrigger,
                        fontSize = 98.sp
                    )
                    if (state.showVnOnCurrent) {
                        Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFFFF1F2), border = BorderStroke(1.dp, Color(0xFFFECDD3))) {
                            Text(
                                text = "🇻🇳 ${target.vnWord} — ${target.sentenceVn}",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF9F1239),
                                textAlign = TextAlign.Center
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    Button(
                        onClick = { onSpeakText(target.word) },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0EA5E9))
                    ) {
                        Text("🔊 Hear Word", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (card.answered) Color(0xFFECFDF5) else Color.White.copy(alpha = 0.85f),
            border = BorderStroke(1.dp, if (card.answered) Color(0xFFA7F3D0) else Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(state.feedbackText, textAlign = TextAlign.Center, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (card.answered) Color(0xFF047857) else Color(0xFF475569))
                if (card.answered) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("“${target.sentenceEn}”", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF065F46), modifier = Modifier.weight(1f, fill = false), textAlign = TextAlign.Center)
                        IconButton(
                            onClick = { onSpeakText(target.sentenceEn); onReplayAnim() },
                            modifier = Modifier.size(28.dp).clip(CircleShape).background(Color(0xFFD1FAE5))
                        ) { Text("🔊", fontSize = 12.sp) }
                    }
                    Text("🇻🇳 ${target.sentenceVn}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFBE123C), textAlign = TextAlign.Center)
                }
            }
        }

        // Zip down options compactly once answered!
        if (card.answered) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                card.options.forEach { opt ->
                    val isWin = opt.word == target.word
                    Surface(
                        modifier = Modifier.weight(1f).height(36.dp).clickable { onSelectOption(opt) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isWin) Color(0xFF10B981) else Color(0xFFF1F5F9),
                        border = BorderStroke(if (isWin) 2.dp else 1.dp, if (isWin) Color(0xFF059669) else Color(0xFFE2E8F0))
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 4.dp)) {
                            Text(
                                text = if (isWin) "✓ ${opt.word}" else opt.word,
                                color = if (isWin) Color.White else Color(0xFF94A3B8),
                                fontWeight = if (isWin) FontWeight.ExtraBold else FontWeight.Medium,
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                card.options.chunked(2).forEach { rowItems ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        rowItems.forEach { opt ->
                            val isWrong = opt.word in card.wrongChoices
                            val bg = if (isWrong) Color(0xFFFFF1F2) else Color.White
                            val fg = if (isWrong) Color(0xFFE11D48) else Color(0xFF1E293B)
                            Surface(
                                modifier = Modifier.weight(1f).height(58.dp).clickable { onSelectOption(opt) },
                                shape = RoundedCornerShape(16.dp),
                                color = bg,
                                border = BorderStroke(2.dp, if (isWrong) Color(0xFFFDA4AF) else Color(0xFFE2E8F0)),
                                shadowElevation = 2.dp
                            ) {
                                Row(modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(opt.word, color = fg, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                                    IconButton(onClick = { onSpeakText(opt.word) }, modifier = Modifier.size(30.dp).clip(CircleShape).background(Color(0xFFE0F2FE))) {
                                        Text("🔊", fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        // ALWAYS-VISIBLE Bottom Prev & Next / Festive Finish Bar
        val isLastCard = state.currentIndex == state.quizCards.size - 1
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilledTonalButton(
                onClick = onPrev,
                enabled = state.currentIndex > 0,
                modifier = Modifier.weight(0.38f).height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("← Prev", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            if (isLastCard && card.answered) {
                Button(
                    onClick = onNext,
                    modifier = Modifier.weight(0.62f).height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(2.dp, Color(0xFFFDE047)),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color(0xFF0F172A)),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                ) {
                    Text("🏆 Finish & Party! 🎉", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                }
            } else {
                Button(
                    onClick = onNext,
                    modifier = Modifier.weight(0.62f).height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (card.answered) Color(0xFF10B981) else Color(0xFF0EA5E9)
                    )
                ) {
                    Text(
                        text = if (isLastCard) "Finish 🎉" else if (card.answered) "Next Word →" else "Skip →",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun WordListScreen(
    category: WordCategory?,
    onSpeakText: (String) -> Unit,
    onBackToQuiz: () -> Unit
) {
    val cat = category ?: return
    val words = WordRepository.wordsFor(cat)

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${cat.icon} ${cat.title} — ${words.size} Words",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF1E293B)
                )
                Text(
                    text = "Tap any word or 🔊 to listen",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }
            Button(
                onClick = onBackToQuiz,
                shape = RoundedCornerShape(50),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Text("← Quiz", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            words.forEachIndexed { idx, item ->
                Surface(
                    modifier = Modifier.fillMaxWidth().clickable { onSpeakText("${item.word}. ${item.sentenceEn}") },
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    shadowElevation = 1.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(cat.softBgColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(item.emoji, fontSize = 26.sp)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${idx + 1}. ${item.word}", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
                            Text(item.sentenceEn, fontSize = 12.sp, color = Color(0xFF475569))
                        }
                        IconButton(
                            onClick = { onSpeakText("${item.word}. ${item.sentenceEn}") },
                            modifier = Modifier.size(34.dp).clip(CircleShape).background(Color(0xFFE0F2FE))
                        ) {
                            Text("🔊", fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LogicScreen(
    state: WordPopV5UiState,
    onSpeakText: (String) -> Unit,
    onReplayAnim: () -> Unit,
    onToggleVn: () -> Unit,
    onSelectOption: (WordItem) -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    val puzzle = state.currentLogic ?: return
    val isMystery = puzzle.mode == LogicMode.MYSTERY_CLUE

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Prominent Kid-Friendly 10-Star Counter Card
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color(0xFFF5F3FF),
            border = BorderStroke(2.dp, Color(0xFFDDD6FE)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${if (isMystery) "🕵️" else "🔎"} Puzzle ${state.logicIndex + 1} / ${state.logicPuzzles.size}",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF5B21B6),
                        fontSize = 15.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalButton(
                            onClick = onToggleVn,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFFFFE4E6), contentColor = Color(0xFFBE123C))
                        ) { Text("🇻🇳 VN", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        Surface(shape = RoundedCornerShape(50), color = Color(0xFFFBBF24)) {
                            Text("⭐ ${state.logicStars}/10", modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), fontWeight = FontWeight.ExtraBold, color = Color(0xFF0F172A), fontSize = 13.sp)
                        }
                    }
                }
                StarJourneyTrail(
                    total = state.logicPuzzles.size,
                    activeIndex = state.logicIndex,
                    answeredAt = { state.logicPuzzles[it].answered },
                    starredAt = { state.logicPuzzles[it].earnedStar }
                )
            }
        }

        // Responsive Logic Card fills remaining height cleanly on every phone!
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clickable {
                    if (puzzle.answered) {
                        onReplayAnim()
                        onSpeakText(puzzle.target.word)
                    } else {
                        onSpeakText(if (isMystery) puzzle.target.clueEn else "Which one does not belong with the others?")
                    }
                },
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(3.dp, Color(0xFFDDD6FE)),
            elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                if (puzzle.answered) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color(0xFFFCD34D),
                        shadowElevation = 3.dp,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp)
                            .clickable {
                                onReplayAnim()
                                onSpeakText(puzzle.target.sentenceEn)
                            }
                    ) {
                        Text(
                            text = puzzle.target.actionBadge,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF0F172A)
                        )
                    }
                }

                Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    VividAnimatedStage(
                        emoji = if (puzzle.answered) puzzle.target.emoji else if (isMystery) "❓" else "🔎",
                        animType = puzzle.target.animType,
                        active = puzzle.answered,
                        triggerKey = state.animTrigger,
                        fontSize = 84.sp
                    )
                    Text(
                        text = if (isMystery) "“${puzzle.target.clueEn}”" else "Which one does NOT belong with the others?",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B),
                        textAlign = TextAlign.Center
                    )
                    if (state.showVnOnCurrent) {
                        Spacer(modifier = Modifier.height(5.dp))
                        Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFFFF1F2), border = BorderStroke(1.dp, Color(0xFFFECDD3))) {
                            Text(
                                text = if (isMystery) "🇻🇳 ${puzzle.target.clueVn}" else "🇻🇳 Hình nào KHÔNG cùng nhóm với 3 hình còn lại?",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF9F1239),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { onSpeakText(if (isMystery) puzzle.target.clueEn else "Which one does not belong with the others?") },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
                    ) {
                        Text("🔊 Hear Clue", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (puzzle.answered) Color(0xFFECFDF5) else Color.White.copy(alpha = 0.85f),
            border = BorderStroke(1.dp, if (puzzle.answered) Color(0xFFA7F3D0) else Color(0xFFE2E8F0)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(state.logicFeedback, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), textAlign = TextAlign.Center, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (puzzle.answered) Color(0xFF047857) else Color(0xFF475569))
        }

        // Zip down options compactly once answered!
        if (puzzle.answered) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                puzzle.options.forEach { opt ->
                    val isWin = opt.word == puzzle.target.word
                    Surface(
                        modifier = Modifier.weight(1f).height(36.dp).clickable { onSelectOption(opt) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isWin) Color(0xFF10B981) else Color(0xFFF1F5F9),
                        border = BorderStroke(if (isWin) 2.dp else 1.dp, if (isWin) Color(0xFF059669) else Color(0xFFE2E8F0))
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 4.dp)) {
                            Text(
                                text = if (isWin) "✓ ${opt.word}" else opt.word,
                                color = if (isWin) Color.White else Color(0xFF94A3B8),
                                fontWeight = if (isWin) FontWeight.ExtraBold else FontWeight.Medium,
                                fontSize = 11.sp,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                puzzle.options.chunked(2).forEach { rowItems ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        rowItems.forEach { opt ->
                            val isWrong = opt.word in puzzle.wrongChoices
                            val bg = if (isWrong) Color(0xFFFFF1F2) else Color.White
                            val fg = if (isWrong) Color(0xFFE11D48) else Color(0xFF1E293B)
                            Surface(
                                modifier = Modifier.weight(1f).height(60.dp).clickable { onSelectOption(opt) },
                                shape = RoundedCornerShape(16.dp),
                                color = bg,
                                border = BorderStroke(2.dp, if (isWrong) Color(0xFFFDA4AF) else Color(0xFFE2E8F0)),
                                shadowElevation = 2.dp
                            ) {
                                Row(modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(if (isMystery) opt.word else "${opt.emoji} ${opt.word}", color = fg, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                                    IconButton(onClick = { onSpeakText(opt.word) }, modifier = Modifier.size(30.dp).clip(CircleShape).background(Color(0xFFEDE9FE))) {
                                        Text("🔊", fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        // ALWAYS-VISIBLE Bottom Prev & Next / Festive Finish Bar
        val isLastPuzzle = state.logicIndex == state.logicPuzzles.size - 1
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilledTonalButton(
                onClick = onPrev,
                enabled = state.logicIndex > 0,
                modifier = Modifier.weight(0.38f).height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("← Prev", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
            if (isLastPuzzle && puzzle.answered) {
                Button(
                    onClick = onNext,
                    modifier = Modifier.weight(0.62f).height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(2.dp, Color(0xFFFDE047)),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B), contentColor = Color(0xFF0F172A)),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                ) {
                    Text("🏆 Finish & Party! 🎉", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                }
            } else {
                Button(
                    onClick = onNext,
                    modifier = Modifier.weight(0.62f).height(52.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (puzzle.answered) Color(0xFF7C3AED) else Color(0xFF0EA5E9)
                    )
                ) {
                    Text(
                        text = if (isLastPuzzle) "Finish 🎉" else if (puzzle.answered) "Next Puzzle →" else "Skip →",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * 5-Second Grand Celebration Screen with dancing trophy, firework sparkles,
 * custom accomplishment message for every score 0-10/10, then Home / New Set of 10!
 */
@Composable
fun CelebrationSummaryScreen(
    state: WordPopV5UiState,
    onSpeakText: (String) -> Unit,
    onPlayAgain: () -> Unit,
    onGoHome: () -> Unit
) {
    val acc = Accomplishments.forScore(state.summaryStars)
    var celebrating by remember(state.summaryRunId) { mutableStateOf(true) }

    val trophyScale = remember { Animatable(1f) }
    val trophyRot = remember { Animatable(0f) }
    val burstProgress = remember { Animatable(0f) }

    LaunchedEffect(state.summaryRunId) {
        celebrating = true
        launch {
            delay(10000L)
            celebrating = false
        }
        launch {
            repeat(10) {
                launch { trophyScale.animateTo(1.28f, tween(420)); trophyScale.animateTo(1.0f, tween(420)) }
                trophyRot.animateTo(-14f, tween(300))
                trophyRot.animateTo(14f, tween(300))
                trophyRot.animateTo(0f, tween(250))
            }
        }
        launch {
            repeat(10) {
                burstProgress.snapTo(0f)
                burstProgress.animateTo(1f, tween(980))
            }
        }
    }

    val bp = burstProgress.value
    val sparkAlpha = if (celebrating && bp > 0f && bp < 1f) (1f - bp) else 0f

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(modifier = Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
            if (celebrating) {
                Box(
                    modifier = Modifier
                        .size(135.dp)
                        .graphicsLayer(scaleX = 0.7f + bp * 0.9f, scaleY = 0.7f + bp * 0.9f, alpha = (1f - bp) * 0.45f)
                        .clip(CircleShape)
                        .background(Color(0xFFFDE047))
                )
                Text("🎆", fontSize = 30.sp, modifier = Modifier.graphicsLayer(translationX = -110f * bp, translationY = -65f * bp, alpha = sparkAlpha))
                Text("🎉", fontSize = 30.sp, modifier = Modifier.graphicsLayer(translationX = 110f * bp, translationY = -65f * bp, alpha = sparkAlpha))
                Text("✨", fontSize = 28.sp, modifier = Modifier.graphicsLayer(translationX = -85f * bp, translationY = 55f * bp, alpha = sparkAlpha))
                Text("🌟", fontSize = 28.sp, modifier = Modifier.graphicsLayer(translationX = 85f * bp, translationY = 55f * bp, alpha = sparkAlpha))
            }
            Text(
                text = acc.icon,
                fontSize = 86.sp,
                modifier = Modifier.graphicsLayer(scaleX = trophyScale.value, scaleY = trophyScale.value, rotationZ = trophyRot.value)
            )
        }

        Text(acc.title, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B), textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(10.dp))

        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
            border = BorderStroke(2.dp, Color(0xFFFCD34D)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    for (i in 0 until 10) {
                        Text(if (i < state.summaryStars) "⭐" else "☆", fontSize = 22.sp, color = if (i < state.summaryStars) Color(0xFFF59E0B) else Color(0xFFCBD5E1))
                    }
                }
                Text(acc.en, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B), textAlign = TextAlign.Center)
                Text("🇻🇳 ${acc.vn}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFBE123C), textAlign = TextAlign.Center)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedButton(onClick = { onSpeakText("${acc.title}! ${acc.en}") }, shape = RoundedCornerShape(50)) {
            Text("🔊 Hear Celebration", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(18.dp))
        Button(
            onClick = onPlayAgain,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
        ) {
            Text("🔄 Start New Set of 10", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(10.dp))
        FilledTonalButton(
            onClick = onGoHome,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text("🏠 Back to Home", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SettingsScreen(
    state: WordPopV5UiState,
    onToggleReadAloud: () -> Unit,
    onToggleSlowMode: () -> Unit,
    onToggleAutoBilingual: () -> Unit,
    onDecreaseFont: () -> Unit,
    onIncreaseFont: () -> Unit,
    onSelectFontStyle: (FontStyleChoice) -> Unit,
    onOpenVersionHistory: () -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(
                painter = painterResource(id = R.drawable.wordpop_logo),
                contentDescription = "WordPop! Kids v5 logo",
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(16.dp))
            )
            Column {
                Text("WordPop! Kids v5", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
                Text("Package: com.wordpop.kids.v5", fontSize = 12.sp, color = Color(0xFF64748B))
            }
        }

        Text("LEARNING PREFERENCES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
        SettingRow("🔊 Read Aloud", "Speak words, clues, and sentences", if (state.readAloudEnabled) "ON" else "OFF", state.readAloudEnabled, onToggleReadAloud)
        SettingRow("🐢 Voice Speed", "Slower voice is easier for 6-year-olds", if (state.slowMode) "Slow" else "Normal", state.slowMode, onToggleSlowMode)
        SettingRow("🇻🇳 Vietnamese Bilingual Bridge", "Auto-show matched Vietnamese hints", if (state.autoBilingualVn) "ON" else "OFF", state.autoBilingualVn, onToggleAutoBilingual)

        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, border = BorderStroke(1.dp, Color(0xFFE2E8F0)), modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("🔠 Font Size", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B))
                    Text("Make words bigger or smaller", fontSize = 11.sp, color = Color(0xFF64748B))
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalButton(onClick = onDecreaseFont, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) { Text("A−", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                    Text("${(state.fontScale * 100).toInt()}%", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = Color(0xFF0284C7))
                    FilledTonalButton(onClick = onIncreaseFont, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) { Text("A+", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                }
            }
        }

        Surface(shape = RoundedCornerShape(16.dp), color = Color.White, border = BorderStroke(1.dp, Color(0xFFE2E8F0)), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("✍️ Font Style", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B))
                FontStyleChoice.entries.chunked(2).forEach { rowChoices ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowChoices.forEach { choice ->
                            val selected = choice == state.fontStyle
                            OutlinedButton(
                                onClick = { onSelectFontStyle(choice) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Color(0xFF0284C7) else Color(0xFFCBD5E1)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (selected) Color(0xFFE0F2FE) else Color.White,
                                    contentColor = if (selected) Color(0xFF0369A1) else Color(0xFF475569)
                                )
                            ) { Text(choice.label, fontFamily = choice.fontFamily, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                        }
                    }
                }
                Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFF8FAFC), border = BorderStroke(1.dp, Color(0xFFE2E8F0)), modifier = Modifier.fillMaxWidth()) {
                    Text("🐶 A dog barks 'woof' and loves to wag its tail!", modifier = Modifier.padding(10.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF334155))
                }
            }
        }

        Text("APP VERSION", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))

        Card(
            modifier = Modifier.fillMaxWidth().clickable { onOpenVersionHistory() },
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFDF4FF)),
            border = BorderStroke(2.dp, Color(0xFFF0ABFC))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Version 5.0  •  CURRENT", fontWeight = FontWeight.ExtraBold, color = Color(0xFF701A75), fontSize = 15.sp)
                    Text("Tap to view full version history (v1.0 → v5.0)", fontSize = 12.sp, color = Color(0xFF86198F))
                }
                Text("›", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFF86198F))
            }
        }

        Button(onClick = onClose, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))) {
            Text("Done", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun VersionHistoryScreen(
    onBackToSettings: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("📜 How WordPop! Evolved", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1E293B))
                Text("Full version history from v1.0 to v5.0", fontSize = 12.sp, color = Color(0xFF64748B))
            }
            Button(
                onClick = onBackToSettings,
                shape = RoundedCornerShape(50),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) { Text("← Settings", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
        }

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            VersionCard(
                title = "Version 5.0 (Current) — 10-Card Quest & Party",
                bg = Color(0xFFFDF4FF), border = Color(0xFFF0ABFC), titleColor = Color(0xFF701A75), bodyColor = Color(0xFF86198F),
                bullets = listOf(
                    "Fixed clickable top-right action verb badge in Quiz, Mystery Clue & Odd One Out (all 100 verbs matched to animations).",
                    "Shorter 10-question random sessions everywhere + 🔄 New 10 Reset button.",
                    "Bright 10-Star visual journey counter lighting up after every card.",
                    "10-second fireworks & dancing trophy celebration with custom bilingual praise for 1/10–10/10.",
                    "English-only 20-word 📖 List inside every category + full-screen responsive layout with always-visible Prev/Next bar."
                )
            )
            VersionCard(
                title = "Version 4.0 — 100 Words, Kitchen & Font Studio",
                bg = Color(0xFFECFEFF), border = Color(0xFFA5F3FC), titleColor = Color(0xFF155E75), bodyColor = Color(0xFF164E63),
                bullets = listOf(
                    "Added 20-word Kitchen (Nhà bếp) category (100 words total).",
                    "Redesigned Family Stuff into 20 Living Room Furniture (Nội thất phòng khách) words.",
                    "Bigger picture stage with vivid squash-and-stretch physics, glowing aura & orbiting particles.",
                    "Expanded Mystery Clue & Odd One Out to draw randomly from all 100 words.",
                    "Added Font Size (A− / A+) and Font Style picker with live preview in Settings."
                )
            )
            VersionCard(
                title = "Version 3.0 — Matched Bilingual & Expressive Motion",
                bg = Color(0xFFFFFBEB), border = Color(0xFFFDE68A), titleColor = Color(0xFF92400E), bodyColor = Color(0xFF78350F),
                bullets = listOf(
                    "1-to-1 matched Vietnamese hints & English echo sentences across all words.",
                    "Expressive sentence animations and floating action badges on correct answers.",
                    "Added ← Prev button to revisit earlier questions without losing stars.",
                    "Added 20-word Stationery (Dụng cụ học tập) category (80 words total)."
                )
            )
            VersionCard(
                title = "Version 2.0 — Mascot Logo, Logic Play & Sentences",
                bg = Color(0xFFEEF2FF), border = Color(0xFFC7D2FE), titleColor = Color(0xFF312E81), bodyColor = Color(0xFF3730A3),
                bullets = listOf(
                    "Cute star-and-puppy mascot logo & custom Android launcher icon.",
                    "Settings screen with voice speed, bilingual toggle & version tracking.",
                    "Full-Sentence Echo + optional 🇻🇳 VN Hint bilingual bridge.",
                    "Launched Logic Play mini-mode (Mystery Clue & Odd One Out) + TTS cold-start queue."
                )
            )
            VersionCard(
                title = "Version 1.0 — The First WordPop!",
                bg = Color.White, border = Color(0xFFE2E8F0), titleColor = Color(0xFF1E293B), bodyColor = Color(0xFF475569),
                bullets = listOf(
                    "60 starter English words across Animals, Vehicles, and Family Stuff.",
                    "4-choice picture flashcards with per-action Read Aloud & Slow/Normal voice speed.",
                    "First-try star counter and GitHub Actions cloud APK builds."
                )
            )
        }
    }
}

@Composable
private fun VersionCard(
    title: String,
    bg: Color,
    border: Color,
    titleColor: Color,
    bodyColor: Color,
    bullets: List<String>
) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = bg), border = BorderStroke(1.5.dp, border), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, fontWeight = FontWeight.ExtraBold, color = titleColor, fontSize = 14.sp)
            bullets.forEach { b ->
                Text("• $b", fontSize = 12.sp, color = bodyColor)
            }
        }
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, badge: String, active: Boolean, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color.White, border = BorderStroke(1.dp, Color(0xFFE2E8F0)), modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF1E293B))
                Text(subtitle, fontSize = 11.sp, color = Color(0xFF64748B))
            }
            Button(
                onClick = onClick,
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (active) Color(0xFF10B981) else Color(0xFFE2E8F0), contentColor = if (active) Color.White else Color(0xFF475569))
            ) { Text(badge, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        }
    }
}
