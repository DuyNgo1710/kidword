package com.wordpop.kids.v5.analytics

import android.content.Context
import android.os.Bundle
import com.google.firebase.analytics.FirebaseAnalytics

/**
 * Kid-safe anonymous feature analytics (no PII, AD_ID disabled in manifest).
 */
class KidsAnalytics(context: Context) {
    private val analytics: FirebaseAnalytics? = runCatching {
        FirebaseAnalytics.getInstance(context.applicationContext)
    }.getOrNull()

    fun logCategoryStarted(category: String) {
        log("category_started", Bundle().apply { putString("category", category) })
    }

    fun logLogicStarted(mode: String) {
        log("logic_started", Bundle().apply { putString("mode", mode) })
    }

    fun logSessionCompleted(mode: String, score: Int) {
        log("session_completed", Bundle().apply {
            putString("mode", mode)
            putLong("score", score.toLong())
        })
    }

    fun logWordListOpened(category: String) {
        log("word_list_opened", Bundle().apply { putString("category", category) })
    }

    fun logVnHintToggled(enabled: Boolean) {
        log("vn_hint_toggled", Bundle().apply { putString("enabled", enabled.toString()) })
    }

    fun logFontChanged(sizePct: Int, style: String) {
        log("font_changed", Bundle().apply {
            putLong("size_pct", sizePct.toLong())
            putString("style", style)
        })
    }

    private fun log(event: String, params: Bundle) {
        runCatching { analytics?.logEvent(event, params) }
    }
}
