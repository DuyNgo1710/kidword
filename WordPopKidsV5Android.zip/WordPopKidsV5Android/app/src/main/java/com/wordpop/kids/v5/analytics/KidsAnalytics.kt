package com.wordpop.kids.v5.analytics

import android.content.Context
import android.os.Bundle
import com.google.firebase.analytics.FirebaseAnalytics

/**
 * Kid-safe anonymous feature analytics (no PII, AD_ID disabled in manifest).
 */
class KidsAnalytics(context: Context) {
    var statusText: String = "Initializing..."
        private set
    var eventsLogged: Int = 0
        private set

    private val analytics: FirebaseAnalytics? = runCatching {
        FirebaseAnalytics.getInstance(context.applicationContext).apply {
            setAnalyticsCollectionEnabled(true)
            setConsent(
                mapOf(
                    FirebaseAnalytics.ConsentType.ANALYTICS_STORAGE to FirebaseAnalytics.ConsentStatus.GRANTED,
                    FirebaseAnalytics.ConsentType.AD_STORAGE to FirebaseAnalytics.ConsentStatus.DENIED,
                    FirebaseAnalytics.ConsentType.AD_USER_DATA to FirebaseAnalytics.ConsentStatus.DENIED,
                    FirebaseAnalytics.ConsentType.AD_PERSONALIZATION to FirebaseAnalytics.ConsentStatus.DENIED
                )
            )
            statusText = "Connected"
        }
    }.onFailure { err ->
        statusText = "Error: ${err.message ?: err.javaClass.simpleName}"
    }.getOrNull()

    fun logAppOpened() {
        log("wordpop_opened", Bundle().apply { putString("app_version", "5.0") })
    }

    fun logCategoryStarted(category: String) {
        log("category_started", Bundle().apply { putString("category", category) })
    }

    fun logLogicStarted(mode: String) {
        log("logic_started", Bundle().apply { putString("mode", mode) })
    }

    fun logSessionCompleted(mode: String, score: Int) {
        log("session_completed", Bundle().apply {
            putString("mode", mode)
            putLong("score", score.toLong())
        })
    }

    fun logWordListOpened(category: String) {
        log("word_list_opened", Bundle().apply { putString("category", category) })
    }

    fun logVnHintToggled(enabled: Boolean) {
        log("vn_hint_toggled", Bundle().apply { putString("enabled", enabled.toString()) })
    }

    fun logFontChanged(sizePct: Int, style: String) {
        log("font_changed", Bundle().apply {
            putLong("size_pct", sizePct.toLong())
            putString("style", style)
        })
    }

    private fun log(event: String, params: Bundle) {
        runCatching {
            analytics?.logEvent(event, params)
            if (analytics != null) eventsLogged += 1
        }.onFailure { err ->
            statusText = "Log error: ${err.message}"
        }
    }
}
