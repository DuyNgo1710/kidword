package com.wordpop.kids.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.wordpop.kids.data.WordRepository
import com.wordpop.kids.model.WordCategory
import com.wordpop.kids.model.WordItem

enum class ScreenMode { HOME, QUIZ, SUMMARY }

data class QuizUiState(
    val screen: ScreenMode = ScreenMode.HOME,
    val readAloudEnabled: Boolean = true,
    val slowMode: Boolean = true,
    val category: WordCategory? = null,
    val deck: List<WordItem> = emptyList(),
    val currentIndex: Int = 0,
    val options: List<WordItem> = emptyList(),
    val answeredCorrectly: Boolean = false,
    val wrongChoices: Set<String> = emptySet(),
    val stars: Int = 0,
    val feedbackText: String = "What is this? Pick the right word!",
    val bestStars: Map<WordCategory, Int> = emptyMap()
) {
    val currentWord: WordItem? get() = deck.getOrNull(currentIndex)
}

class FlashcardViewModel : ViewModel() {

    var uiState by mutableStateOf(QuizUiState())
        private set

    fun toggleReadAloud(): Boolean {
        val next = !uiState.readAloudEnabled
        uiState = uiState.copy(readAloudEnabled = next)
        return next
    }

    fun toggleSlowMode(): Boolean {
        val next = !uiState.slowMode
        uiState = uiState.copy(slowMode = next)
        return next
    }

    fun goHome() {
        uiState = uiState.copy(screen = ScreenMode.HOME)
    }

    fun startCategory(category: WordCategory) {
        val shuffledDeck = WordRepository.wordsFor(category).shuffled()
        val firstTarget = shuffledDeck.first()
        uiState = uiState.copy(
            screen = ScreenMode.QUIZ,
            category = category,
            deck = shuffledDeck,
            currentIndex = 0,
            options = buildOptions(category, firstTarget),
            answeredCorrectly = false,
            wrongChoices = emptySet(),
            stars = 0,
            feedbackText = "What is this? Pick the right word!"
        )
    }

    /** Returns spoken feedback message if auto-read is enabled. */
    fun selectOption(chosen: WordItem): String {
        val target = uiState.currentWord ?: return ""
        if (uiState.answeredCorrectly) return chosen.word

        return if (chosen.word == target.word) {
            val earnedStar = uiState.wrongChoices.isEmpty()
            uiState = uiState.copy(
                answeredCorrectly = true,
                stars = if (earnedStar) uiState.stars + 1 else uiState.stars,
                feedbackText = "Yes! It's ${target.word}!"
            )
            "Great job! ${target.word}!"
        } else {
            uiState = uiState.copy(
                wrongChoices = uiState.wrongChoices + chosen.word,
                feedbackText = "That's ${chosen.word} - try again!"
            )
            "${chosen.word}. Try again!"
        }
    }

    fun nextQuestion(): String? {
        val category = uiState.category ?: return null
        val nextIdx = uiState.currentIndex + 1
        return if (nextIdx >= uiState.deck.size) {
            val updatedBest = uiState.bestStars.toMutableMap()
            val prevBest = updatedBest[category] ?: 0
            if (uiState.stars > prevBest) {
                updatedBest[category] = uiState.stars
            }
            uiState = uiState.copy(
                screen = ScreenMode.SUMMARY,
                bestStars = updatedBest
            )
            "Awesome job! You finished all ${uiState.deck.size} words in ${category.title}!"
        } else {
            val nextTarget = uiState.deck[nextIdx]
            uiState = uiState.copy(
                currentIndex = nextIdx,
                options = buildOptions(category, nextTarget),
                answeredCorrectly = false,
                wrongChoices = emptySet(),
                feedbackText = "What is this? Pick the right word!"
            )
            null
        }
    }

    private fun buildOptions(category: WordCategory, target: WordItem): List<WordItem> {
        val distractors = WordRepository.wordsFor(category)
            .filter { it.word != target.word }
            .shuffled()
            .take(3)
        return (distractors + target).shuffled()
    }
}
