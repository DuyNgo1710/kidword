package com.wordpop.kids.data

import com.wordpop.kids.model.WordCategory
import com.wordpop.kids.model.WordItem

object WordRepository {

    private val animals = listOf(
        WordItem("Dog", "🐶"),
        WordItem("Cat", "🐱"),
        WordItem("Cow", "🐮"),
        WordItem("Pig", "🐷"),
        WordItem("Duck", "🦆"),
        WordItem("Frog", "🐸"),
        WordItem("Lion", "🦁"),
        WordItem("Tiger", "🐯"),
        WordItem("Bear", "🐻"),
        WordItem("Monkey", "🐵"),
        WordItem("Elephant", "🐘"),
        WordItem("Giraffe", "🦒"),
        WordItem("Rabbit", "🐰"),
        WordItem("Mouse", "🐭"),
        WordItem("Bird", "🐦"),
        WordItem("Fish", "🐟"),
        WordItem("Turtle", "🐢"),
        WordItem("Whale", "🐳"),
        WordItem("Bee", "🐝"),
        WordItem("Butterfly", "🦋")
    )

    private val vehicles = listOf(
        WordItem("Car", "🚗"),
        WordItem("Bus", "🚌"),
        WordItem("Truck", "🚚"),
        WordItem("Train", "🚂"),
        WordItem("Bike", "🚲"),
        WordItem("Plane", "✈️"),
        WordItem("Boat", "⛵"),
        WordItem("Ship", "🚢"),
        WordItem("Taxi", "🚕"),
        WordItem("Police Car", "🚓"),
        WordItem("Fire Truck", "🚒"),
        WordItem("Ambulance", "🚑"),
        WordItem("Tractor", "🚜"),
        WordItem("Rocket", "🚀"),
        WordItem("Helicopter", "🚁"),
        WordItem("Scooter", "🛴"),
        WordItem("Motorcycle", "🏍️"),
        WordItem("Subway", "🚇"),
        WordItem("Van", "🚐"),
        WordItem("Canoe", "🛶")
    )

    private val familyStuff = listOf(
        WordItem("Bed", "🛏️"),
        WordItem("Chair", "🪑"),
        WordItem("Couch", "🛋️"),
        WordItem("Clock", "⏰"),
        WordItem("Lamp", "💡"),
        WordItem("Book", "📖"),
        WordItem("Cup", "🥤"),
        WordItem("Spoon", "🥄"),
        WordItem("Fork", "🍴"),
        WordItem("Plate", "🍽️"),
        WordItem("Key", "🔑"),
        WordItem("Door", "🚪"),
        WordItem("Window", "🪟"),
        WordItem("Phone", "📱"),
        WordItem("TV", "📺"),
        WordItem("Mirror", "🪞"),
        WordItem("Soap", "🧼"),
        WordItem("Toothbrush", "🪥"),
        WordItem("Broom", "🧹"),
        WordItem("Backpack", "🎒")
    )

    fun wordsFor(category: WordCategory): List<WordItem> = when (category) {
        WordCategory.ANIMALS -> animals
        WordCategory.VEHICLES -> vehicles
        WordCategory.FAMILY_STUFF -> familyStuff
    }
}
