# WordPop! Kids English Flashcards (Android)

A kid-friendly Android flashcard game built with **Kotlin**, **Jetpack Compose**, **Material 3**, and native Android **TextToSpeech** for 6-year-old English learners.

## Features
- **3 Categories × 20 Simple Words (60 words total):** Animals, Vehicles, and Family Stuff.
- **4-Choice Picture Quiz:** Displays a large, colorful flashcard illustration with 4 shuffled answer choices.
- **Read-Aloud on Every Action:**
  - Tap the speaker icon on any category card to hear its name.
  - Tap the picture card or **Hear Word** button to hear the target word aloud.
  - Tap the **🔊** button on any of the 4 choices to listen before picking.
  - Spoken encouragement on every answer + global **Read ON/OFF** and **Slow / Normal** voice speed toggles.
- **First-Try Star Counter & Celebration Screen** at the end of every 20-word deck.

## How to Open & Build APK in Android Studio
1. Unzip `KidsWordPopAndroid.zip`.
2. Open **Android Studio** (Ladybug or newer) and select **Open** -> choose the `KidsWordPopAndroid` folder.
3. Wait for Gradle sync to finish (requires internet on your PC to download Gradle/Compose libraries).
4. Connect an Android phone (with USB debugging enabled) or start an Android Emulator, then click **Run ▶**.
5. To build a shareable APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

## Customizing Pictures Later
Each word currently uses a crisp oversized vector/emoji graphic in `WordRepository.kt` so the app works immediately with zero external image assets. To swap in custom PNG/WebP illustrations later, place images in `app/src/main/res/drawable/` and add an optional `@DrawableRes val imageRes: Int? = null` field to `WordItem`.
